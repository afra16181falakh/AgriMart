//// using AgriMartAPI.Repositories;
//// using Microsoft.AspNetCore.Mvc;
//// using Microsoft.Extensions.Logging;
//// using System;
//// using System.Threading.Tasks;

//// namespace AgriMartAPI.Controllers
//// {
////     [Route("api/[controller]")]
////     [ApiController]
////     public class PaymentMethodController : ControllerBase
////     {
////         private readonly IPaymentMethodRepository _paymentRepo;
////         private readonly ILogger<PaymentMethodController> _logger;

////         public PaymentMethodController(IPaymentMethodRepository paymentRepo, ILogger<PaymentMethodController> logger)
////         {
////             _paymentRepo = paymentRepo;
////             _logger = logger;
////         }

////         [HttpGet]
////         public async Task<IActionResult> GetPaymentMethods()
////         {
////             try
////             {
////                 var methods = await _paymentRepo.GetAll(); // CORRECTED
////                 return Ok(methods);
////             }
////             catch (Exception ex)
////             {
////                 _logger.LogError(ex, "Error fetching payment methods.");
////                 return StatusCode(500, "An internal server error occurred.");
////             }
////         }
////     }
//// }
