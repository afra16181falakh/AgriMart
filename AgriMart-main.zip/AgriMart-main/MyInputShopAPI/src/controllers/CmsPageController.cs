using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Security.Claims;

namespace AgriMartAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CmsPageController : ControllerBase
    {
        private readonly ICmsPageRepository _cmsPageRepository;

        public CmsPageController(ICmsPageRepository cmsPageRepository)
        {
            _cmsPageRepository = cmsPageRepository;
        }

        [HttpGet("by-slug/{slug}")]
        public async Task<IActionResult> GetCmsPageBySlug(string slug)
        {
            var page = await _cmsPageRepository.GetCmsPageBySlug(slug);
            if (page == null || !page.IsPublished)
            {
                return NotFound();
            }
            return Ok(page);
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> CreateCmsPage([FromBody] CmsPage page)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var userIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userIdString) || !Guid.TryParse(userIdString, out Guid userId))
            {
                return Unauthorized("User ID claim not found or invalid in token. Please log in.");
            }
            try
            {
                Guid newPageId = await _cmsPageRepository.CreateCmsPage(page, userId);
                page.Id = newPageId;
                if (newPageId == Guid.Empty)
                {
                    Console.WriteLine("[ERROR] CreateCmsPage: Database did not return a valid GUID for the new page.");
                    return StatusCode(500, "Failed to create CMS page. Could not retrieve valid generated ID.");
                }
                return CreatedAtAction(nameof(GetCmsPageBySlug), new { slug = page.Slug }, page);
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"[CRITICAL ERROR] Failed to create CMS page: {ex}");
                return StatusCode(500, "An internal server error occurred while creating the CMS page.");
            }
        }

        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> UpdateCmsPage(Guid id, [FromBody] CmsPage page)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (id != page.Id)
            {
                return BadRequest("CMS Page ID in URL does not match ID in body.");
            }

            var userIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userIdString) || !Guid.TryParse(userIdString, out Guid userId))
            {
                return Unauthorized("User ID not found or invalid in token for update operation.");
            }

            try
            {
                var updated = await _cmsPageRepository.UpdateCmsPage(page, userId, DateTime.UtcNow);
                if (updated)
                {
                    return NoContent();
                }
                return NotFound("CMS page not found or update failed.");
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"[CRITICAL ERROR] Failed to update CMS page: {ex}");
                return StatusCode(500, "An internal server error occurred while updating the CMS page.");
            }
        }

        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteCmsPage(Guid id)
        {
            var deleted = await _cmsPageRepository.DeleteCmsPage(id);
            if (deleted)
            {
                return NoContent();
            }
            return NotFound("CMS page not found or deletion failed.");
        }
    }
}