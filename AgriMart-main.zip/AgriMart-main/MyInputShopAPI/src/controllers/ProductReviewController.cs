// using AgriMartAPI.models;
// using AgriMartAPI.Repositories;
// using Microsoft.AspNetCore.Mvc;
// using Microsoft.Extensions.Logging;
// using System;
// using System.Threading.Tasks;

// namespace AgriMartAPI.Controllers
// {
//     [Route("api/[controller]")]
//     [ApiController]
//     public class ProductReviewController : ControllerBase
//     {
//         private readonly IProductReviewRepository _reviewRepo;
//         private readonly ILogger<ProductReviewController> _logger;

//         public ProductReviewController(IProductReviewRepository reviewRepo, ILogger<ProductReviewController> logger)
//         {
//             _reviewRepo = reviewRepo;
//             _logger = logger;
//         }

//         [HttpGet("product/{productId}")]
//         public async Task<IActionResult> GetReviewsForProduct(Guid productId)
//         {
//             try
//             {
//                 var reviews = await _reviewRepo.GetByProductId(productId);
//                 return Ok(reviews);
//             }
//             catch (Exception ex)
//             {
//                 _logger.LogError(ex, "Error fetching reviews for product {ProductId}", productId);
//                 return StatusCode(500, "An internal server error occurred.");
//             }
//         }

//         [HttpPost]
//         public async Task<IActionResult> CreateReview([FromBody] ProductReview review)
//         {
//             try
//             {
//                 if (review == null) return BadRequest();
//                 var createdReview = await _reviewRepo.Create(review);
//                 return CreatedAtAction(nameof(GetReviewsForProduct), new { productId = createdReview.ProductId }, createdReview);
//             }
//             catch (Exception ex)
//             {
//                 _logger.LogError(ex, "Error creating new review.");
//                 return StatusCode(500, "An internal server error occurred.");
//             }
//         }
//     }
// }