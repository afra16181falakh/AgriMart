using AgriMartAPI.Interfaces;
using AgriMartAPI.Models; // Make sure UserLoginDto, UserRegisterDto, UserProfile, UserDto are accessible
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims; // Required for ClaimTypes
using System; // Required for Guid

namespace AgriMartAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")] // This defines the base route, e.g., /api/Authentication
    public class AuthenticationController : ControllerBase
    {
        private readonly IAuthRepository _authRepo;
        private readonly ILogger<AuthenticationController> _logger;

        public AuthenticationController(IAuthRepository authRepo, ILogger<AuthenticationController> logger)
        {
            _authRepo = authRepo;
            _logger = logger;
        }

        /// <summary>
        /// Registers a new user.
        /// </summary>
        /// <param name="registerDto">User registration details.</param>
        /// <returns>A response indicating success or failure of registration.</returns>
        [AllowAnonymous] // This endpoint does not require authentication
        [HttpPost("register")] // Defines the route as POST /api/Authentication/register
        public async Task<IActionResult> Register([FromBody] UserRegisterDto registerDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var result = await _authRepo.RegisterAsync(registerDto);
                if (result == null)
                {
                    // This could be due to email already existing or other validation in AuthRepository
                    return BadRequest("Registration failed: User already exists or invalid data provided.");
                }
                return Ok(new { Message = "Registration successful", UserId = result });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Registration failed for email: {Email}", registerDto.Email);
                return StatusCode(500, "Internal server error during registration.");
            }
        }

        /// <summary>
        /// Authenticates a user and returns a JWT token upon successful login.
        /// </summary>
        /// <param name="loginDto">User login credentials.</param>
        /// <returns>A JWT token if login is successful.</returns>
        [AllowAnonymous] // This endpoint does not require authentication
        [HttpPost("login")] // Defines the route as POST /api/Authentication/login
        public async Task<IActionResult> Login([FromBody] UserLoginDto loginDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var token = await _authRepo.LoginAsync(loginDto);
                if (string.IsNullOrEmpty(token))
                {
                    return Unauthorized("Invalid credentials."); // Covers incorrect email or password
                }
                return Ok(new { Token = token }); // Returns the JWT token to the frontend
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Login failed for email: {Email}", loginDto.Email);
                return StatusCode(500, "Internal server error during login.");
            }
        }

        /// <summary>
        /// Retrieves the profile details of the currently authenticated user.
        /// </summary>
        /// <returns>The UserDto containing non-sensitive user profile information.</returns>
        [Authorize] // This endpoint requires a valid JWT token in the Authorization header
        [HttpGet("me")] // Defines the route as GET /api/Authentication/me
        public async Task<ActionResult<UserDto>> GetCurrentUserProfile()
        {
            // The [Authorize] attribute ensures that 'User.Identity.IsAuthenticated' is true here.
            // We extract the user's unique identifier (UserId GUID) from the JWT token's claims.
            // ASSUMPTION: The UserId (Guid) is stored in the JWT claim with type ClaimTypes.NameIdentifier.
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userIdClaim))
            {
                _logger.LogWarning("Authenticated user's ClaimTypes.NameIdentifier is missing or empty. This indicates a potential issue with JWT token generation or validation setup.");
                return Unauthorized("User identifier not found in token. Please log in again.");
            }

            // Attempt to parse the string UserId from the claim into a Guid.
            if (!Guid.TryParse(userIdClaim, out Guid userId))
            {
                _logger.LogError("Failed to parse userId claim '{UserIdClaim}' as GUID. The token might be malformed or the claim type is incorrect.", userIdClaim);
                return Unauthorized("Invalid user identifier format in token.");
            }

            try
            {
                // Fetch the full UserProfile entity from the repository using the extracted UserId.
                var userProfile = await _authRepo.GetUserProfileByIdAsync(userId);

                if (userProfile == null)
                {
                    _logger.LogWarning("User profile not found in database for ID: {UserId}. This might happen if the user was deleted after their token was issued.", userId);
                    return NotFound("User profile not found.");
                }

                // Map the UserProfile entity to the UserDto to return only the necessary, non-sensitive data to the frontend.
                var userDto = new UserDto
                {
                    UserId = userProfile.UserId,
                    Name = userProfile.Name,
                    Email = userProfile.Email,
                    PhoneNumber = userProfile.PhoneNumber, // Include the phone number as requested
                    Role = userProfile.Role
                    // Add any other non-sensitive properties from UserProfile that the frontend needs
                    // For example: IsActive = userProfile.IsActive, CreatedDate = userProfile.CreatedDate
                };

                return Ok(userDto);
            }
            catch (Exception ex)
            {
                // Log any exceptions that occur during the process of fetching or mapping the user profile.
                _logger.LogError(ex, "An error occurred while fetching user profile for ID: {UserId}", userId);
                return StatusCode(500, "Internal server error while fetching user profile.");
            }
        }
    }
}