// --- File: AgriMartAPI/Controllers/OrdersController.cs ---

using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System; // REQUIRED for Guid

namespace AgriMartAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;

        public OrdersController(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        [HttpGet] // GET /api/orders
        public async Task<IActionResult> GetOrders()
        {
            var orders = await _orderRepository.GetAll();
            return Ok(orders);
        }

        [HttpGet("{id}")] // GET /api/orders/{id}
        public async Task<IActionResult> GetOrderById(Guid id) // CHANGED: Parameter type from 'int' to 'Guid'
        {
            var order = await _orderRepository.GetById(id);
            if (order == null)
            {
                return NotFound();
            }
            return Ok(order);
        }

        [HttpPost] // POST /api/orders
        public async Task<IActionResult> CreateOrder([FromBody] Order order)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            // order.Id will be generated in the repository if database default is NEWID()
            // The repository's Create method will return the generated Guid.

            var newOrderId = await _orderRepository.Create(order);

            // CHANGED: Check against Guid.Empty for success.
            // newOrderId is already a Guid, and GetOrderById expects a Guid.
            if (newOrderId != Guid.Empty)
            {
                // Assign the generated ID to the order object before returning
                order.Id = newOrderId;
                // CreatedAtAction uses the route parameter name (id) and its value
                return CreatedAtAction(nameof(GetOrderById), new { id = newOrderId }, order);
            }
            return StatusCode(500, "Failed to create order.");
        }
    }
}