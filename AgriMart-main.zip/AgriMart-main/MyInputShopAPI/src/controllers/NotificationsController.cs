using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration; // Still needed for Configuration
using Microsoft.Extensions.Logging;
using AgriMartAPI.Models; // CORRECTED: Changed 'models' to 'Models'
using AgriMartAPI.Repositories; // For IErrorHandlingRepository
using System;
using System.Collections.Generic;
using System.Threading.Tasks; // REQUIRED for async methods
using System.Linq;

namespace AgriMartAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationsController : ControllerBase
    {
        // Removed _connectionString if it's not directly used in this controller anymore
        // It's handled by DbExecutor which is injected into repositories.
        // private readonly string _connectionString;

        private readonly ILogger<NotificationsController> _logger;
        private readonly IErrorHandlingRepository _errorHandlingRepo;
        // If you had a NotificationRepository, you would inject it here:
        // private readonly INotificationRepository _notificationRepo;

        public NotificationsController(IConfiguration configuration, // Keep if still needed for other purposes
                                       ILogger<NotificationsController> logger,
                                       IErrorHandlingRepository errorHandlingRepo
                                       /* , INotificationRepository notificationRepo */)
        {
            // If _connectionString is not used, remove this line too:
            // _connectionString = configuration.GetConnectionString("DefaultConnection")
            //     ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
            _logger = logger;
            _errorHandlingRepo = errorHandlingRepo;
            // _notificationRepo = notificationRepo;
        }

        [HttpPost]
        public async Task<IActionResult> CreateNotification([FromBody] Notification notification) // CHANGED to async Task<IActionResult>
        {
            try
            {
                if (notification == null)
                {
                    _logger.LogWarning("CreateNotification: Received null notification object.");
                    return BadRequest("Notification data is required.");
                }

                if (notification.NotificationId == 0)
                {
                    notification.NotificationId = new Random().Next(100000, 999999);
                }
                notification.DateSent = DateTime.UtcNow;
                notification.IsRead = false;

                _logger.LogInformation("Successfully processed POST to create notification. ID: {NotificationId}, Message: {Message}", notification.NotificationId, notification.Message);
                
                return CreatedAtAction(nameof(GetNotificationById), new { id = notification.NotificationId }, notification);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating notification.");
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling // AWAITED
                {
                    Message = "Failed to create notification.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = $"{ControllerContext.ActionDescriptor.ControllerName}.{ControllerContext.ActionDescriptor.ActionName}",
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred while creating the notification.");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllNotifications() // CHANGED to async Task<IActionResult>
        {
            try
            {
                _logger.LogInformation("Executing GET to fetch all notifications (dummy data).");
                var dummyNotifications = new List<Notification>
                {
                    new Notification { NotificationId = 1, Message = "Your order #123 has been shipped.", UserId = Guid.NewGuid(), DateSent = DateTime.UtcNow.AddHours(-1), IsRead = false },
                    new Notification { NotificationId = 2, Message = "Welcome to AgriMart!", UserId = Guid.NewGuid(), DateSent = DateTime.UtcNow.AddDays(-2), IsRead = true }
                };
                return Ok(dummyNotifications);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting all notifications.");
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling // AWAITED
                {
                    Message = "Failed to retrieve all notifications.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = $"{ControllerContext.ActionDescriptor.ControllerName}.{ControllerContext.ActionDescriptor.ActionName}",
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred while retrieving notifications.");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetNotificationById(int id) // CHANGED to async Task<IActionResult>
        {
            try
            {
                _logger.LogInformation("Executing GET to fetch notification with ID: {NotificationId} (dummy data).", id);
                if (id <= 0 || id > 10000000)
                {
                    _logger.LogInformation("Notification with ID {NotificationId} not found (dummy condition).", id);
                    return NotFound($"Notification with ID {id} not found.");
                }

                var dummyNotification = new Notification
                {
                    NotificationId = id,
                    Message = $"Details for notification ID {id}: Your item is ready for pickup!",
                    UserId = Guid.NewGuid(),
                    DateSent = DateTime.UtcNow,
                    IsRead = false
                };
                return Ok(dummyNotification);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting notification by ID {NotificationId}.", id);
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling // AWAITED
                {
                    Message = $"Failed to retrieve notification by ID: {id}.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = $"{ControllerContext.ActionDescriptor.ControllerName}.{ControllerContext.ActionDescriptor.ActionName}",
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred while retrieving the notification.");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateNotification(int id, [FromBody] Notification notification) // CHANGED to async Task<IActionResult>
        {
            try
            {
                if (notification == null)
                {
                    _logger.LogWarning("UpdateNotification: Received null notification object for ID {NotificationId}.", id);
                    return BadRequest("Notification data is required.");
                }

                if (id != notification.NotificationId)
                {
                    _logger.LogWarning("Mismatched IDs for update. URL ID: {UrlId}, Body ID: {BodyId}", id, notification.NotificationId);
                    return BadRequest("ID in URL does not match ID in body.");
                }
                
                _logger.LogInformation("Executing PUT to update notification with ID: {NotificationId} (dummy update).", id);
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating notification with ID {NotificationId}.", id);
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling // AWAITED
                {
                    Message = $"Failed to update notification with ID: {id}.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = $"{ControllerContext.ActionDescriptor.ControllerName}.{ControllerContext.ActionDescriptor.ActionName}",
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred while updating the notification.");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteNotification(int id) // CHANGED to async Task<IActionResult>
        {
            try
            {
                _logger.LogInformation("Executing DELETE for notification with ID: {NotificationId} (dummy delete).", id);
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting notification with ID {NotificationId}.", id);
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling // AWAITED
                {
                    Message = $"Failed to delete notification with ID: {id}.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = $"{ControllerContext.ActionDescriptor.ControllerName}.{ControllerContext.ActionDescriptor.ActionName}",
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred while deleting the notification.");
            }
        }
    }
}