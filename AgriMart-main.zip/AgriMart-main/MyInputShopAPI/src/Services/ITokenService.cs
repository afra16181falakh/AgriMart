// src/Interfaces/ITokenService.cs
using AgriMartAPI.Models; // For UserProfile
using System.Threading.Tasks;

namespace AgriMartAPI.Interfaces
{
    public interface ITokenService
    {
        Task<string> GenerateJwtToken(UserProfile user); // Ensure this method is declared here
    }
}