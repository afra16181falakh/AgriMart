// src/Interfaces/IAuthService.cs
using AgriMartAPI.Models; // For UserProfile
using System.Threading.Tasks;

namespace AgriMartAPI.Interfaces
{
    public interface IAuthService
    {
        Task<UserProfile?> RegisterUserAsync(string name, string email, string phoneNumber, string password);
        Task<bool> GenerateOtpAsync(string phoneNumber);
        Task<string?> VerifyOtpAndGenerateTokenAsync(string phoneNumber, string otp);
        Task<string> GenerateJwtToken(UserProfile user); // Ensure this method is declared here
    }
}