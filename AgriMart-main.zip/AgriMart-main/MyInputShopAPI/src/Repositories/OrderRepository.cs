// --- File: AgriMartAPI/Repositories/OrderRepository.cs ---

using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using Microsoft.Data.SqlClient; // Still needed for raw SqlConnection
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly string _connectionString;

        public OrderRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                                ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
        }

        public async Task<IEnumerable<Order>> GetAll()
        {
            var orders = new List<Order>();
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = @"SELECT Id, UserId, ShippingAddressId, OrderDate, TotalAmount,
                                     OrderStatusId, TrackingNumber, CreatedDate, ModifiedDate
                              FROM Orders";
                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            orders.Add(MapOrderFromReader(reader));
                        }
                    }
                }
            }
            return orders;
        }

        public async Task<Order?> GetById(Guid id) // Parameter type is Guid
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = @"SELECT Id, UserId, ShippingAddressId, OrderDate, TotalAmount,
                                     OrderStatusId, TrackingNumber, CreatedDate, ModifiedDate
                              FROM Orders WHERE Id = @Id";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", id); // Passes Guid parameter
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return MapOrderFromReader(reader);
                        }
                    }
                }
            }
            return null;
        }

        public async Task<Guid> Create(Order order) // Returns Guid, as Id is Guid
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = @"INSERT INTO Orders (Id, UserId, ShippingAddressId, OrderDate, TotalAmount,
                                                  OrderStatusId, TrackingNumber, CreatedDate, ModifiedDate)
                              OUTPUT INSERTED.Id
                              VALUES (@Id, @UserId, @ShippingAddressId, @OrderDate, @TotalAmount,
                                      @OrderStatusId, @TrackingNumber, @CreatedDate, @ModifiedDate)";
                using (var command = new SqlCommand(query, connection))
                {
                    order.Id = Guid.NewGuid(); // Assign a new GUID before inserting
                    // Ensure default dates if not provided by the model (or if DB does not default)
                    order.OrderDate = order.OrderDate == default(DateTime) ? DateTime.UtcNow : order.OrderDate;
                    order.CreatedDate = order.CreatedDate == default(DateTime) ? DateTime.UtcNow : order.CreatedDate;

                    command.Parameters.AddWithValue("@Id", order.Id);
                    command.Parameters.AddWithValue("@UserId", order.UserId);
                    command.Parameters.AddWithValue("@ShippingAddressId", order.ShippingAddressId); // Now int
                    command.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                    command.Parameters.AddWithValue("@TotalAmount", order.TotalAmount);
                    command.Parameters.AddWithValue("@OrderStatusId", order.OrderStatusId);
                    command.Parameters.AddWithValue("@TrackingNumber", (object)order.TrackingNumber ?? DBNull.Value);
                    command.Parameters.AddWithValue("@CreatedDate", order.CreatedDate);
                    command.Parameters.AddWithValue("@ModifiedDate", (object)order.ModifiedDate ?? DBNull.Value);

                    return (Guid)(await command.ExecuteScalarAsync())!; // Returns the new Guid
                }
            }
        }

        public async Task<bool> Update(Order order)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = @"UPDATE Orders SET
                                UserId = @UserId,
                                ShippingAddressId = @ShippingAddressId,
                                OrderDate = @OrderDate,
                                TotalAmount = @TotalAmount,
                                OrderStatusId = @OrderStatusId,
                                TrackingNumber = @TrackingNumber,
                                ModifiedDate = @ModifiedDate
                              WHERE Id = @Id";
                using (var command = new SqlCommand(query, connection))
                {
                    order.ModifiedDate = DateTime.UtcNow; // Set modified date on update

                    command.Parameters.AddWithValue("@UserId", order.UserId);
                    command.Parameters.AddWithValue("@ShippingAddressId", order.ShippingAddressId); // Now int
                    command.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                    command.Parameters.AddWithValue("@TotalAmount", order.TotalAmount);
                    command.Parameters.AddWithValue("@OrderStatusId", order.OrderStatusId);
                    command.Parameters.AddWithValue("@TrackingNumber", (object)order.TrackingNumber ?? DBNull.Value);
                    command.Parameters.AddWithValue("@ModifiedDate", order.ModifiedDate);
                    command.Parameters.AddWithValue("@Id", order.Id);
                    return await command.ExecuteNonQueryAsync() > 0;
                }
            }
        }

        public async Task<bool> Delete(Guid id) // Parameter type is Guid
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = "DELETE FROM Orders WHERE Id = @Id";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);
                    return await command.ExecuteNonQueryAsync() > 0;
                }
            }
        }

        public async Task<int> GetTotalOrderCount()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = "SELECT COUNT(*) FROM Orders";
                using (var command = new SqlCommand(query, connection))
                {
                    return (int)(await command.ExecuteScalarAsync())!;
                }
            }
        }

        public async Task<decimal> GetTotalRevenue()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = "SELECT SUM(TotalAmount) FROM Orders";
                using (var command = new SqlCommand(query, connection))
                {
                    var result = await command.ExecuteScalarAsync();
                    return result == DBNull.Value ? 0m : (decimal)result;
                }
            }
        }

        // Helper method to map data from SqlDataReader to Order object
        private Order MapOrderFromReader(SqlDataReader reader)
        {
            return new Order
            {
                Id = reader.GetGuid(reader.GetOrdinal("Id")),
                UserId = reader.GetGuid(reader.GetOrdinal("UserId")),
                ShippingAddressId = reader.GetInt32(reader.GetOrdinal("ShippingAddressId")), // <<<<< CRUCIAL FIX: Changed from GetGuid to GetInt32
                OrderDate = reader.GetDateTime(reader.GetOrdinal("OrderDate")),
                TotalAmount = reader.GetDecimal(reader.GetOrdinal("TotalAmount")),
                OrderStatusId = reader.GetGuid(reader.GetOrdinal("OrderStatusId")),
                TrackingNumber = reader.IsDBNull(reader.GetOrdinal("TrackingNumber")) ? null : reader.GetString(reader.GetOrdinal("TrackingNumber")),
                CreatedDate = reader.GetDateTime(reader.GetOrdinal("CreatedDate")),
                ModifiedDate = reader.IsDBNull(reader.GetOrdinal("ModifiedDate")) ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("ModifiedDate"))
            };
        }
    }
}