// File: src/AgriMartAPI/Repositories/INotificationRepository.cs (or Interfaces/INotificationRepository.cs)

using AgriMartAPI.Models;         // REQUIRED: To know about the Notification type
using System.Collections.Generic;
using System.Threading.Tasks;
using System;                     // For Guid
using AgriMartAPI.Interfaces;     // Optional, only needed if other methods use interfaces from here

namespace AgriMartAPI.Repositories // Or AgriMartAPI.Interfaces
{
    public interface INotificationRepository
    {
        Task Create(Notification notification);
        Task<IEnumerable<Notification>> GetByUserId(Guid userId); // Changed List<Notification> to IEnumerable for flexibility
        Task MarkAsRead(int notificationId);
        Task Delete(int notificationId); // Added a delete method as common
    }
}