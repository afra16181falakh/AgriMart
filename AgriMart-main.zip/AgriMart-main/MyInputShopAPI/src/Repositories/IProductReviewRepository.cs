using AgriMartAPI.models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Repositories
{
    public interface IProductReviewRepository
    {
        Task<IEnumerable<ProductReview>> GetByProductId(Guid productId);
        Task<ProductReview> Create(ProductReview review);
        Task<bool> Delete(int reviewId);
    }
}
