// src/Interfaces/IOrderItemRepository.cs
using AgriMartAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Interfaces
{
    public interface IOrderItemRepository
    {
        // This is the ONLY definition of AddOrderItem you should have in this interface
        Task<int> AddOrderItem(OrderItem orderItem);
        Task<IEnumerable<OrderItem>> GetOrderItemsByOrderId(int orderId);
        // Add any other methods if you have them, but no duplicates!
    }
}