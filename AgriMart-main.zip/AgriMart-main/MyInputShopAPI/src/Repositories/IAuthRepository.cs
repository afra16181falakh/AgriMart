using AgriMartAPI.Models;
using System;
using System.Threading.Tasks;

namespace AgriMartAPI.Interfaces
{
    public interface IAuthRepository
    {
        Task<Guid?> RegisterAsync(UserRegisterDto registerDto);
        Task<string> LoginAsync(UserLoginDto loginDto);
        // NEW: Method to get user profile by UserId
        Task<UserProfile?> GetUserProfileByIdAsync(Guid userId); // Allow null for not found
    }
}