// using AgriMartAPI.models;
// using System.Collections.Generic;
// using System.Threading.Tasks;

// namespace AgriMartAPI.Repositories
// {
//     public interface IPaymentMethodRepository
//     {
//         Task<IEnumerable<PaymentMethod>> GetAll();
//     }
// }