
namespace AgriMartAPI.Repositories
{
 
    public static class StoredProcedures
    {
        public static class Addresses
        {
            public const string GetByUserId = "dbo.sp_Addresses_GetByUserId";
            public const string GetById = "dbo.sp_Addresses_GetById";
            public const string Create = "dbo.sp_Addresses_Create";
            public const string Update = "dbo.sp_Addresses_Update";
            public const string Delete = "dbo.sp_Addresses_Delete";
        }

        public static class Cart
        {
            
            public const string GetItemsByUserId = "dbo.sp_CartItems_GetByUserId";
            
            
        }

        
    }
}