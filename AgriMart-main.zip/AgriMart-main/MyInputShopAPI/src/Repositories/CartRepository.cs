// --- File: AgriMartAPI/Repositories/CartRepository.cs ---

using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Threading.Tasks;

namespace AgriMartAPI.Repositories
{
    public class CartRepository : ICartRepository
    {
        private readonly string _connectionString;

        public CartRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                                ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found in configuration.");
        }

        public async Task<IEnumerable<CartItem>> GetCartItems(Guid userId)
        {
            var cartItems = new List<CartItem>();
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = @"SELECT c.UserId, c.ProductId, c.Quantity, p.Name AS ProductName, p.Price, p.Description AS ProductDescription
                              FROM CartItems c -- FIX: Changed 'Carts' to 'CartItems'
                              JOIN Products p ON c.ProductId = p.ProductId
                              WHERE c.UserId = @UserId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            cartItems.Add(new CartItem
                            {
                                UserId = reader.GetGuid(reader.GetOrdinal("UserId")),
                                ProductId = reader.GetGuid(reader.GetOrdinal("ProductId")),
                                Quantity = reader.GetInt32(reader.GetOrdinal("Quantity")),
                                ProductName = reader.GetString(reader.GetOrdinal("ProductName")),
                                Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                ProductDescription = reader.IsDBNull(reader.GetOrdinal("ProductDescription")) ? null : reader.GetString(reader.GetOrdinal("ProductDescription"))
                            });
                        }
                    }
                }
            }
            return cartItems;
        }

        public async Task<bool> AddOrUpdateItem(Guid userId, Guid productId, int quantity)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var checkQuery = "SELECT COUNT(*) FROM CartItems WHERE UserId = @UserId AND ProductId = @ProductId"; // FIX: Changed 'Carts' to 'CartItems'
                using (var checkCommand = new SqlCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@UserId", userId);
                    checkCommand.Parameters.AddWithValue("@ProductId", productId);

                    int count = (int)(await checkCommand.ExecuteScalarAsync())!;

                    if (count > 0)
                    {
                        // Update existing item
                        var updateQuery = "UPDATE CartItems SET Quantity = Quantity + @Quantity, DateAdded = GETUTCDATE() WHERE UserId = @UserId AND ProductId = @ProductId"; // FIX: Changed 'Carts' to 'CartItems'
                        using (var updateCommand = new SqlCommand(updateQuery, connection))
                        {
                            updateCommand.Parameters.AddWithValue("@Quantity", quantity);
                            updateCommand.Parameters.AddWithValue("@UserId", userId);
                            updateCommand.Parameters.AddWithValue("@ProductId", productId);
                            return await updateCommand.ExecuteNonQueryAsync() > 0;
                        }
                    }
                    else
                    {
                        // Add new item
                        var insertQuery = "INSERT INTO CartItems (UserId, ProductId, Quantity, DateAdded) VALUES (@UserId, @ProductId, @Quantity, GETUTCDATE())"; // FIX: Changed 'Carts' to 'CartItems'
                        using (var insertCommand = new SqlCommand(insertQuery, connection))
                        {
                            insertCommand.Parameters.AddWithValue("@UserId", userId);
                            insertCommand.Parameters.AddWithValue("@ProductId", productId);
                            insertCommand.Parameters.AddWithValue("@Quantity", quantity);
                            return await insertCommand.ExecuteNonQueryAsync() > 0;
                        }
                    }
                }
            }
        }

        public async Task<bool> RemoveItem(Guid userId, Guid productId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = "DELETE FROM CartItems WHERE UserId = @UserId AND ProductId = @ProductId"; // FIX: Changed 'Carts' to 'CartItems'
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.Parameters.AddWithValue("@ProductId", productId);
                    return await command.ExecuteNonQueryAsync() > 0;
                }
            }
        }

        public async Task<bool> ClearCart(Guid userId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = "DELETE FROM CartItems WHERE UserId = @UserId"; // FIX: Changed 'Carts' to 'CartItems'
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    return await command.ExecuteNonQueryAsync() > 0;
                }
            }
        }

        public async Task<bool> UpdateItemQuantity(Guid userId, Guid productId, int quantity)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = "UPDATE CartItems SET Quantity = @Quantity, DateAdded = GETUTCDATE() WHERE UserId = @UserId AND ProductId = @ProductId"; // FIX: Changed 'Carts' to 'CartItems'
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Quantity", quantity);
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.Parameters.AddWithValue("@ProductId", productId);
                    var affectedRows = await command.ExecuteNonQueryAsync();
                    return affectedRows > 0;
                }
            }
        }
    }
}