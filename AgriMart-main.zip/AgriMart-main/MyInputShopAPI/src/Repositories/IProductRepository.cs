// --- File: AgriMartAPI/Interfaces/IProductRepository.cs ---

using AgriMartAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System; // REQUIRED for Guid

namespace AgriMartAPI.Interfaces
{
    public interface IProductRepository
    {
        Task<IEnumerable<Product>> GetAllProducts();
        Task<Product?> GetProductById(Guid id); // CHANGED: Parameter type to Guid
        Task<Guid> AddProduct(Product product); // CHANGED: Return type to Guid
        Task<bool> UpdateProduct(Product product);
        Task<bool> UpdateProductStock(Guid id, int quantity); // CHANGED: Parameter type to Guid
        Task<bool> DeleteProduct(Guid id); // CHANGED: Parameter type to Guid
        Task<IEnumerable<Product>> SearchProductsAsync(string searchTerm);
        Task<int> GetInStockProductCount();
    }
}