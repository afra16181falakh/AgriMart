// --- File: AgriMartAPI/Interfaces/ICartRepository.cs ---

using AgriMartAPI.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Interfaces
{
    public interface ICartRepository
    {
        Task<IEnumerable<CartItem>> GetCartItems(Guid userId);
        Task<bool> AddOrUpdateItem(Guid userId, Guid productId, int quantity);
        Task<bool> RemoveItem(Guid userId, Guid productId);
        Task<bool> ClearCart(Guid userId);
        Task<bool> UpdateItemQuantity(Guid userId, Guid productId, int quantity); // NEW
    }
}