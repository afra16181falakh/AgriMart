// --- File: AgriMartAPI/Repositories/AuthRepository.cs ---

using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using Microsoft.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using BCrypt.Net;

namespace AgriMartAPI.Repositories
{
    public class AuthRepository : IAuthRepository
    {
        private readonly string _connectionString;
        private readonly IConfiguration _configuration;
        private readonly IUserProfileRepository _userProfileRepository;
        private readonly string _jwtKey;

        public AuthRepository(IConfiguration configuration, IUserProfileRepository userProfileRepository)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                                ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
            _configuration = configuration;
            _userProfileRepository = userProfileRepository;

            _jwtKey = _configuration["Jwt:Key"]
                      ?? throw new InvalidOperationException("JWT:Key configuration is missing.");
        }

        public async Task<Guid?> RegisterAsync(UserRegisterDto registerDto)
        {
            var existingUser = await _userProfileRepository.GetUserProfileByEmail(registerDto.Email);
            if (existingUser != null)
            {
                return null;
            }

            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(registerDto.Password);

            Guid newUserId = Guid.NewGuid();
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = @"INSERT INTO UserProfiles (UserId, Name, Email, PhoneNumber, PasswordHash, Role, IsActive, CreatedDate, LastLogin)
                              VALUES (@UserId, @Name, @Email, @PhoneNumber, @PasswordHash, @Role, @IsActive, @CreatedDate, @LastLogin)";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", newUserId);
                    command.Parameters.AddWithValue("@Name", registerDto.Name);
                    command.Parameters.AddWithValue("@Email", registerDto.Email);
                    command.Parameters.AddWithValue("@PhoneNumber", registerDto.PhoneNumber ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                    command.Parameters.AddWithValue("@Role", "Customer");
                    command.Parameters.AddWithValue("@IsActive", true);
                    command.Parameters.AddWithValue("@CreatedDate", DateTime.UtcNow);
                    command.Parameters.AddWithValue("@LastLogin", (object)DBNull.Value);

                    var affectedRows = await command.ExecuteNonQueryAsync();
                    if (affectedRows > 0)
                    {
                        return newUserId;
                    }
                    return null;
                }
            }
        }

        public async Task<string?> LoginAsync(UserLoginDto loginDto) // Changed return type to Task<string?> to remove CS8603 warning
        {
            var user = await _userProfileRepository.GetUserProfileByEmail(loginDto.Email);
            if (user == null || user.IsActive == false)
            {
                return null;
            }

            if (!BCrypt.Net.BCrypt.Verify(loginDto.Password, user.PasswordHash))
            {
                return null;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var updateQuery = "UPDATE UserProfiles SET LastLogin = @LastLogin WHERE UserId = @UserId";
                using (var updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@LastLogin", DateTime.UtcNow);
                    // FIX: Changed 'command.Parameters' to 'updateCommand.Parameters'
                    // FIX: Removed duplicate line
                    updateCommand.Parameters.AddWithValue("@UserId", user.UserId);
                    await updateCommand.ExecuteNonQueryAsync();
                }
            }

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_jwtKey); // Uses the non-nullable _jwtKey

            var claims = new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role ?? "Customer")
            });

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = claims,
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                Issuer = _configuration["Jwt:Issuer"] ?? "your_default_issuer",
                Audience = _configuration["Jwt:Audience"] ?? "your_default_audience"
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        public async Task<UserProfile?> GetUserProfileByIdAsync(Guid userId)
        {
            return await _userProfileRepository.GetUserProfileById(userId);
        }
    }
}