using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data; // REQUIRED for CommandType

namespace AgriMartAPI.Repositories
{
    public class DeliveryChargeRulesRepository : IDeliveryChargeRulesRepository
    {
        private readonly IDBExecutor _dbExecutor;

        public DeliveryChargeRulesRepository(IDBExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor;
        }

        public async Task<IEnumerable<DeliveryChargeRule>> GetAllDeliveryChargeRules()
        {
            // FIX: Specify CommandType.StoredProcedure
            return await _dbExecutor.QueryAsync<DeliveryChargeRule>("sp_GetAllDeliveryChargeRules", null, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> AddDeliveryChargeRule(DeliveryChargeRule rule)
        {
            // FIX: Add rule.RuleName parameter AND specify CommandType.StoredProcedure
            // sp_AddDeliveryChargeRule also explicitly returns SCOPE_IDENTITY() as RuleId
            return await _dbExecutor.ExecuteScalarAsync<int>("sp_AddDeliveryChargeRule", new
            {
                rule.RuleName,      // ADDED THIS PARAMETER
                rule.MinOrderAmount,
                rule.MaxOrderAmount,
                rule.ChargeAmount,
                rule.IsActive
            }, commandType: CommandType.StoredProcedure);
        }

        public async Task<bool> UpdateDeliveryChargeRule(DeliveryChargeRule rule)
        {
            // --- CRITICAL FIX: Use ExecuteScalarAsync<int> to capture the explicit @@ROWCOUNT ---
            // sp_UpdateDeliveryChargeRule explicitly returns @@ROWCOUNT
            int affectedRows = await _dbExecutor.ExecuteScalarAsync<int>("sp_UpdateDeliveryChargeRule", new
            {
                rule.RuleId,
                rule.RuleName,      // ADDED THIS PARAMETER
                rule.MinOrderAmount,
                rule.MaxOrderAmount,
                rule.ChargeAmount,
                rule.IsActive
            }, commandType: CommandType.StoredProcedure);
            return affectedRows > 0;
        }

        public async Task<bool> DeleteDeliveryChargeRule(int ruleId)
        {
            // --- CRITICAL FIX: Use ExecuteScalarAsync<int> to capture the explicit @@ROWCOUNT ---
            // Assuming sp_DeleteDeliveryChargeRule also explicitly returns @@ROWCOUNT
            int affectedRows = await _dbExecutor.ExecuteScalarAsync<int>("sp_DeleteDeliveryChargeRule", new { RuleId = ruleId }, commandType: CommandType.StoredProcedure);
            return affectedRows > 0;
        }
    }
}