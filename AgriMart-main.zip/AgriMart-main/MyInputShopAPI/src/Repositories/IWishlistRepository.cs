// using AgriMartAPI.models;
// using System;
// using System.Collections.Generic;
// using System.Threading.Tasks;

// namespace AgriMartAPI.Repositories
// {
//     public interface IWishlistRepository
//     {
//         Task<IEnumerable<Product>> GetByUserId(string userId);
//         Task AddItem(string userId, string productId);
//         Task<bool> RemoveItem(string userId, string productId);
//         Task<bool> IsItemInWishlist(string userId, string productId);
//         Task<bool> Clear(string userId);
//     }
// }