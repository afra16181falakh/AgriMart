// --- File: AgriMartAPI/Interfaces/IUserProfileRepository.cs ---

using AgriMartAPI.Models;
using System;
using System.Collections.Generic; // Required for IEnumerable<UserProfile>
using System.Threading.Tasks;

namespace AgriMartAPI.Interfaces
{
    public interface IUserProfileRepository
    {
        Task<UserProfile?> GetUserProfileByEmail(string email);
        Task<UserProfile?> GetUserProfileByPhoneNumber(string phoneNumber);
        Task<Guid?> CreateUserProfile(UserProfile userProfile);

        // Required by AuthRepository for GET /api/Authentication/me
        Task<UserProfile?> GetUserProfileById(Guid userId);

        // Required by ManagerController (these cause the CS1061 errors if missing)
        Task<int> GetUserCount();
        Task<IEnumerable<UserProfile>> GetAllUserProfiles();
        Task<bool> UpdateUserProfile(UserProfile userProfile);
        Task<bool> DeleteUserProfile(Guid userId);
    }
}