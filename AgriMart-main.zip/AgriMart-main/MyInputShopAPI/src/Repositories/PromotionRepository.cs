// using AgriMartAPI.Constants;
// using AgriMartAPI.models;
// using Microsoft.Data.SqlClient;
// using System.Collections.Generic;
// using System.Data;
// using System.Linq;
// using System.Threading.Tasks;

// namespace AgriMartAPI.Repositories
// {
//     public class PromotionRepository : IPromotionRepository
//     {
//         private readonly IDbExecutor _dbExecutor;
//         public PromotionRepository(IDbExecutor dbExecutor) { _dbExecutor = dbExecutor; }
        
//         public async Task<IEnumerable<Promotion>> GetAllActive()
//         {
//             return await _dbExecutor.QueryAsync(StoredProcedureNames.Promotions.GetAllActive, MapToPromotion, commandType: CommandType.StoredProcedure);
//         }

//         public async Task<Promotion?> GetByCode(string code)
//         {
//             var parameters = new[] { new SqlParameter("@Code", code) };
//             var result = await _dbExecutor.QueryAsync(StoredProcedureNames.Promotions.GetByCode, MapToPromotion, parameters, CommandType.StoredProcedure);
//             return result.FirstOrDefault();
//         }

//         private Promotion MapToPromotion(SqlDataReader reader)
//         {
//             return new Promotion { PromotionId = reader.GetInt32(reader.GetOrdinal("PromotionId")), Code = reader.GetString(reader.GetOrdinal("Code")), Description = reader.GetString(reader.GetOrdinal("Description")), Discount = reader.GetDecimal(reader.GetOrdinal("Discount")), StartDate = reader.GetDateTime(reader.GetOrdinal("StartDate")), EndDate = reader.GetDateTime(reader.GetOrdinal("EndDate")), IsActive = reader.GetBoolean(reader.GetOrdinal("IsActive")) };
//         }
//     }
// }