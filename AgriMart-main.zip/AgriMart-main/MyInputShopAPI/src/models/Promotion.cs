using System;
using System.ComponentModel.DataAnnotations;

namespace AgriMartAPI.models
{
    public class Promotion
    {
        [Key]
        public int PromotionId { get; set; }
        [Required]
        public string Code { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        [Required]
        public decimal Discount { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool IsActive { get; set; }
    }
}
