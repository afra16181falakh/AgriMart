// --- File: AgriMartAPI/Models/UserDto.cs ---
using System;

namespace AgriMartAPI.Models
{
    public class UserDto
    {
        public Guid UserId { get; set; }
        public required string Name { get; set; } // Added 'required'
        public required string Email { get; set; } // Added 'required'
        public required string PhoneNumber { get; set; } // Added 'required' (assuming it's always provided after login, or make it nullable 'string?')
        public required string Role { get; set; } // Added 'required'
        // You can add other non-sensitive properties from UserProfile here if needed by the frontend
        // public bool IsActive { get; set; }
        // public DateTime CreatedDate { get; set; }
    }
}