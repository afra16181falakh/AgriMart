using System;

namespace AgriMartAPI.Models
{
    public class Cart // This seems to represent a single cart item row
    {
        public int CartId { get; set; }        // Primary Key for the cart item
        public Guid UserId { get; set; }       // Foreign Key to the User
        public int ProductId { get; set; }     // Foreign Key to the Product
        public int Quantity { get; set; }      // Quantity of the product in the cart
        public DateTime DateAdded { get; set; } // When the item was added/last updated
    }
}