// --- File: AgriMartAPI/Models/Product.cs ---
using System;
using System.ComponentModel.DataAnnotations;

namespace AgriMartAPI.Models
{
    public class Product
    {
        // Change from int to Guid
        [Key] // Assuming this is your primary key
        public Guid ProductId { get; set; } // CHANGED: Type to Guid

        [Required]
        [MaxLength(255)]
        public string Name { get; set; } = string.Empty;

        public string? Description { get; set; }

        [Required]
        public decimal Price { get; set; }

        [Required]
        public int StockQuantity { get; set; }

        // CategoryId can remain int as per your Category table's Id
        public int? CategoryId { get; set; } // Assuming nullable as per your DB schema allowing NULLs on FK

        public string? ImageUrl { get; set; }

        public bool IsActive { get; set; } = true; // Default to active

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        public DateTime? ModifiedDate { get; set; }
    }
}