namespace AgriMartAPI.Models
{
    public class OrderStatus
    {
        public int StatusId { get; set; }
        public required string StatusName { get; set; }
    }
}