// --- File: AgriMartAPI/Models/UserLoginDto.cs ---
using System.ComponentModel.DataAnnotations;

namespace AgriMartAPI.Models
{
    public class UserLoginDto
    {
        [Required]
        [EmailAddress]
        public required string Email { get; set; } // Added 'required'
        [Required]
        public required string Password { get; set; } // Added 'required'
    }
}