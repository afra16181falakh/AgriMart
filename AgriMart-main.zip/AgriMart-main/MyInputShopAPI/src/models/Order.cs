// --- File: AgriMartAPI/Models/Order.cs ---
using System;
using System.ComponentModel.DataAnnotations; // For [Key] if you use it

namespace AgriMartAPI.Models
{
    public class Order
    {
        [Key] // Assuming 'Id' is your primary key
        public Guid Id { get; set; } // Correctly Guid

        [Required]
        public Guid UserId { get; set; } // Correctly Guid

        [Required]
        public int ShippingAddressId { get; set; } // <<<<< CRUCIAL FIX: Changed from Guid to int

        [Required]
        public DateTime OrderDate { get; set; }

        [Required]
        public decimal TotalAmount { get; set; }

        [Required]
        public Guid OrderStatusId { get; set; } // Correctly Guid (matches dbo.OrderStatus.Id)

        public string? TrackingNumber { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }
    }
}