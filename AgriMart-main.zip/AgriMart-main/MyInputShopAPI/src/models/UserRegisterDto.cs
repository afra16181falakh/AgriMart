// --- File: AgriMartAPI/Models/UserRegisterDto.cs ---
using System.ComponentModel.DataAnnotations;

namespace AgriMartAPI.Models
{
    public class UserRegisterDto
    {
        [Required]
        public required string Name { get; set; } // Added 'required'
        [Required]
        [EmailAddress]
        public required string Email { get; set; } // Added 'required'
        public string? PhoneNumber { get; set; } // Already nullable
        [Required]
        public required string Password { get; set; } // Added 'required'
    }
}