// File: src/AgriMartAPI/Models/Notification.cs

using System; // Required for Guid and DateTime

namespace AgriMartAPI.Models // <--- THIS IS THE NAMESPACE WHERE 'Notification' IS DEFINED
{
    public class Notification
    {
        public int NotificationId { get; set; }   // Primary Key, often auto-incremented
        public Guid UserId { get; set; }          // The user who receives the notification
        public string Message { get; set; } = string.Empty; // The content of the notification
        public DateTime DateSent { get; set; }    // When the notification was sent
        public bool IsRead { get; set; }          // Has the user read it?
        // Add other properties as needed, e.g., NotificationType, RelatedEntityId, etc.
    }
}