using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;
using AgriMartAPI.Repositories; // For repository implementations (including OrderStatusRepository)
using AgriMartAPI.Interfaces; // REQUIRED for IDBExecutor and other interfaces
using AgriMartAPI.Services; // For AuthService, TokenService
using Microsoft.AspNetCore.Cors;
using AgriMartAPI.Middleware; // Assuming your custom middleware is here
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Net.Http; // Potentially needed for some service implementations if they use HttpClient
using Microsoft.AspNetCore.Builder; // Required for WebApplication and middleware
using Microsoft.Extensions.DependencyInjection; // Required for AddScoped
using Microsoft.AspNetCore.Http; // Required for WriteAsync

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
if (string.IsNullOrEmpty(connectionString)) { throw new InvalidOperationException("DB Connection string not found."); }

builder.Services.AddLogging(configure => configure.AddConsole()
                                                 .SetMinimumLevel(LogLevel.Information));

// Register your DbExecutor and Repositories
builder.Services.AddScoped<IDBExecutor>(provider => new DbExecutor(connectionString));

// Existing Repositories
builder.Services.AddScoped<IUserProfileRepository, UserProfileRepository>();
builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<IAddressRepository, AddressRepository>();
builder.Services.AddScoped<ICartRepository, CartRepository>();
builder.Services.AddScoped<IOrderStatusRepository, OrderStatusRepository>(); // Ensure OrderStatusRepository.cs exists
builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// ADDED THIS LINE: The previously missing IAuthRepository registration
builder.Services.AddScoped<IAuthRepository, AuthRepository>();
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

// ADDED from last steps
builder.Services.AddScoped<IOrderRepository, OrderRepository>();
builder.Services.AddScoped<IOrderItemRepository, OrderItemRepository>();

// Error Handling Repository (ensure this is present from previous steps)
builder.Services.AddScoped<IErrorHandlingRepository, ErrorHandlingRepository>();

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// NEW ADDITIONS START HERE for the missing endpoints/functionality
// Register the new repositories created in previous steps
builder.Services.AddScoped<ICmsPageRepository, CmsPageRepository>();
builder.Services.AddScoped<IDeliveryChargeRulesRepository, DeliveryChargeRulesRepository>();
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

// Register your Services (ensure these are uncommented if already defined)
builder.Services.AddScoped<ITokenService, TokenService>();
builder.Services.AddScoped<IAuthService, AuthService>();


builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo { Title = "AgriMart API", Version = "v1" });

    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization", Type = SecuritySchemeType.Http, Scheme = "Bearer", BearerFormat = "JWT",
        In = ParameterLocation.Header, Description = "Enter 'Bearer' followed by a space and your JWT token."
    });
    options.AddSecurityRequirement(new OpenApiSecurityRequirement {
        { new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }}, new string[] {} }
    });
});

// Configure CORS
builder.Services.AddCors(options => {
    options.AddPolicy("AllowSpecificOrigin", policy => {
        // IMPORTANT: If you are using ngrok or other public access, add that URL here.
        // For example: .WithOrigins("http://localhost:5123", "https://localhost:7123", "https://your-ngrok-url.ngrok-free.app")
        policy.WithOrigins("http://localhost:5123", "https://localhost:7123")
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// Configure Authentication (JWT Bearer)
builder.Services.AddAuthentication(options => {
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options => {
    options.TokenValidationParameters = new TokenValidationParameters {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!))
    };
    options.Events = new JwtBearerEvents
    {
        OnAuthenticationFailed = context =>
        {
            var logger = context.HttpContext.RequestServices.GetRequiredService<ILoggerFactory>().CreateLogger(nameof(JwtBearerEvents));
            logger.LogError("Authentication failed: {0}", context.Exception.Message);
            return Task.CompletedTask;
        },
        OnTokenValidated = context =>
        {
            var logger = context.HttpContext.RequestServices.GetRequiredService<ILoggerFactory>().CreateLogger(nameof(JwtBearerEvents));
            var claimsIdentity = context.Principal?.Identity as ClaimsIdentity;
            if (claimsIdentity != null)
            {
                logger.LogInformation("Token validated for user: {0}, Role: {1}",
                    claimsIdentity.FindFirst(ClaimTypes.Name)?.Value,
                    claimsIdentity.FindFirst(ClaimTypes.Role)?.Value);
            }
            return Task.CompletedTask;
        }
    };
});

// Configure Authorization (Role-Based Access Control)
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("ManagerOnly", policy => policy.RequireRole("Manager"));
    options.AddPolicy("AdminOnly", policy => policy.RequireRole("Admin")); // Keep if you use an "Admin" role
    options.AddPolicy("CustomerOnly", policy => policy.RequireRole("Customer")); // Keep if you use a "Customer" role
});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI(options => { options.SwaggerEndpoint("/swagger/v1/swagger.json", "AgriMart API v1"); });
}
else
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

// Custom Middleware
app.Use(async (context, next) => {
    Console.WriteLine($"[Inline Middleware] Request started: {context.Request.Method} {context.Request.Path}");
    await next(context);
    Console.WriteLine($"[Inline Middleware] Request finished: {context.Request.Method} {context.Request.Path} with status {context.Response.StatusCode}");
});
app.UseRequestTimer(); // Assuming this is defined in AgriMartAPI.Middleware

app.UseRouting();

app.UseCors("AllowSpecificOrigin");

app.UseAuthentication();
app.UseAuthorization();

app.MapWhen(context => context.Request.Path == "/", appBranch => {
    appBranch.Run(async context => {
        context.Response.ContentType = "text/plain";
        await context.Response.WriteAsync("Welcome to AgriMart API! Try /swagger for API documentation.");
    });
});

app.MapControllers();

app.Run();