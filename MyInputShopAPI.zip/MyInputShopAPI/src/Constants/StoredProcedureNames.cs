namespace AgriMartAPI.Constants
{
    public static class StoredProcedureNames
    {
        public static class Address
        {
            public const string Create = "dbo.sp_Address_Create";
            public const string GetById = "dbo.sp_Address_GetById";
            public const string GetByUserId = "dbo.sp_Address_GetByUserId";
            public const string Update = "dbo.sp_Address_Update";
            public const string Delete = "dbo.sp_Address_Delete";
        }

        public static class Products
        {
            public const string Create = "dbo.sp_Products_Create";
            public const string GetById = "dbo.sp_Products_GetById";
            public const string GetAll = "dbo.sp_Products_GetAll";
            public const string Update = "dbo.sp_Products_Update";
            public const string Delete = "dbo.sp_Products_Delete";
        }

        public static class Categories
        {
            public const string Create = "dbo.sp_Categories_Create";
            public const string GetById = "dbo.sp_Categories_GetById";
            public const string GetAll = "dbo.sp_Categories_GetAll";
            public const string Update = "dbo.sp_Categories_Update";
            public const string Delete = "dbo.sp_Categories_Delete";
        }

        public static class Wishlist
        {
            public const string AddItem = "dbo.sp_Wishlist_AddItem";
            public const string RemoveItem = "dbo.sp_Wishlist_RemoveItem";
            public const string GetByUserId = "dbo.sp_Wishlist_GetByUserId";
            public const string Clear = "dbo.sp_Wishlist_Clear";
        }

        public static class Cart
        {
            public const string AddOrUpdateItem = "dbo.sp_Cart_AddOrUpdateItem";
            public const string RemoveItem = "dbo.sp_Cart_RemoveItem";
            public const string GetByUserId = "dbo.sp_Cart_GetByUserId";
            public const string Clear = "dbo.sp_Cart_Clear";
            public const string UpdateItemQuantity = "dbo.sp_Cart_UpdateItemQuantity";
        }

        public static class Orders
        {
            public const string Create = "dbo.sp_Orders_Create";
            public const string GetById = "dbo.sp_Orders_GetById";
            public const string GetByUserId = "dbo.sp_Orders_GetByUserId";
            public const string UpdateStatus = "dbo.sp_Orders_UpdateStatus";
        }

        public static class OrderItems
        {
            public const string Create = "dbo.sp_OrderItems_Create";
        }

        public static class UserProfile
        {
            public const string Create = "dbo.sp_UserProfile_Create";
            public const string GetById = "dbo.sp_UserProfile_GetById";
            public const string GetByEmail = "dbo.sp_UserProfile_GetByEmail";
            public const string Update = "dbo.sp_UserProfile_Update";
            public const string Delete = "dbo.sp_UserProfile_Delete"; // ADDED THIS LINE
        }

        public static class ProductReviews
        {
            public const string Create = "dbo.sp_ProductReviews_Create";
            public const string GetByProductId = "dbo.sp_ProductReviews_GetByProductId";
            public const string Update = "dbo.sp_ProductReviews_Update";
            public const string Delete = "dbo.sp_ProductReviews_Delete";
        }

        public static class Promotions
        {
            public const string Create = "dbo.sp_Promotions_Create";
            public const string GetByCode = "dbo.sp_Promotions_GetByCode";
            public const string GetAllActive = "dbo.sp_Promotions_GetAllActive";
            public const string Update = "dbo.sp_Promotions_Update";
            public const string Delete = "dbo.sp_Promotions_Delete";
        }

        public static class OrderStatus
        {
            public const string GetAll = "dbo.sp_OrderStatus_GetAll";
            public const string GetById = "dbo.sp_OrderStatus_GetById";
        }

        public static class PaymentMethods
        {
            public const string GetAll = "dbo.sp_PaymentMethods_GetAll";
            public const string GetById = "dbo.sp_PaymentMethods_GetById";
        }

        public static class Notifications
        {
            public const string Create = "dbo.sp_Notifications_Create";
            public const string GetUnreadByUserId = "dbo.sp_Notifications_GetUnreadByUserId";
            public const string MarkAsRead = "dbo.sp_Notifications_MarkAsRead";
        }
    }
}