using System;
using System.ComponentModel.DataAnnotations;

namespace AgriMartAPI.Models
{
    public class CartItem // This is likely a DTO for displaying cart contents
    {
        public Guid UserId { get; set; }
        public Guid ProductId { get; set; }
        [Range(1, int.MaxValue, ErrorMessage = "Quantity must be at least 1.")]
        public int Quantity { get; set; }
        public string? ProductName { get; set; }
        public decimal? Price { get; set; }
        public string? ProductDescription { get; set; }
    }
}