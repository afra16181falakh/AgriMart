using System; // For Guid

namespace AgriMartAPI.Models
{
    public class CmsPage
    {
        // Matches DB: 'Id' [uniqueidentifier] -> C# 'Guid'
        public Guid Id { get; set; }

        // Matches DB: 'Title' [nvarchar] -> C# 'string'
        public required string Title { get; set; }

        // Matches DB: 'Slug' [nvarchar] -> C# 'string'
        public required string Slug { get; set; }

        // Matches DB: 'ContentHtml' [nvarchar(max)] -> C# 'string' (was 'Content')
        public required string ContentHtml { get; set; }

        // Matches DB: 'IsPublished' [bit] -> C# 'bool' (was 'IsActive')
        public bool IsPublished { get; set; }

        // Add other properties from your dbo.CmsPage table if you intend to use them
        // For example:
        // public string? MetaKeywords { get; set; }
        // public string? MetaDescription { get; set; }
        // public int? StatusId { get; set; }
        // public string? CreatedBy { get; set; }
        // public DateTime CreatedDate { get; set; }
        // public string? ModifiedBy { get; set; }
        // public DateTime? ModifiedDate { get; set; }
    }
}