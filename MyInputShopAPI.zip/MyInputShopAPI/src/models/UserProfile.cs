// --- File: AgriMartAPI/Models/UserProfile.cs ---

using System;
using System.ComponentModel.DataAnnotations;

namespace AgriMartAPI.Models
{
    public class UserProfile
    {
        [Key]
        public Guid UserId { get; set; }

        // --- FIX: Added 'required' modifier to solve CS8618 warnings ---
        public required string Name { get; set; }
        public required string Email { get; set; }
        public required string PhoneNumber { get; set; }
        public required string PasswordHash { get; set; }
        public required string Role { get; set; }

        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? LastLogin { get; set; }
    }
}