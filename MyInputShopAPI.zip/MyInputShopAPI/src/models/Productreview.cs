using System;
using System.ComponentModel.DataAnnotations;

namespace AgriMartAPI.models
{
    public class ProductReview
    {
        [Key]
        public int ReviewId { get; set; }
        [Required]
        public Guid ProductId { get; set; }
        [Required]
        public Guid UserId { get; set; }
        [Range(1, 5)]
        public int Rating { get; set; }
        public string Comment { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
        public string UserName { get; set; } = string.Empty;
    }
}
