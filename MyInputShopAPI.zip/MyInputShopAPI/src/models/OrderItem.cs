namespace AgriMartAPI.Models
{
    public class OrderItem
    {
        public int OrderItemId { get; set; }
        public int OrderId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; } // <<< ADD THIS LINE: To fix the CS1061 error
        // You might have a Product navigation property here too, if applicable:
        // public Product? Product { get; set; }
        // Or other properties like ItemName, ImageUrl if you store product details denormalized
        // public string? ItemName { get; set; }
    }
}