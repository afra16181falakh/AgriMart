using System; // Required for Guid and DateTime
using System.ComponentModel.DataAnnotations; // Still useful for [Required]

namespace AgriMartAPI.Models
{
    public class Address
    {
        public int AddressId { get; set; } // Primary Key, maps to 'Id' in DB

        public Guid UserId { get; set; } // Foreign Key to a User, assuming Guid type for User IDs

        [Required(ErrorMessage = "Street address is required.")]
        public string Street { get; set; } = string.Empty;

        [Required(ErrorMessage = "City is required.")]
        public string City { get; set; } = string.Empty;

        [Required(ErrorMessage = "State is required.")]
        public string State { get; set; } = string.Empty;

        [Required(ErrorMessage = "Zip Code is required.")]
        public string ZipCode { get; set; } = string.Empty;

        // --- NEW/UPDATED PROPERTIES BASED ON YOUR DB SCHEMA ---

        [Required(ErrorMessage = "Address Line 1 is required.")] // Based on your DB schema 'is_nullable = 0' for AddressLine1
        public string AddressLine1 { get; set; } = string.Empty;

        public string? AddressLine2 { get; set; } // Nullable in DB, hence 'string?'

        public string? Country { get; set; } // Nullable in DB, hence 'string?'

        public string? FullName { get; set; } // Nullable in DB, hence 'string?'

        public string? PhoneNumber { get; set; } // Nullable in DB, hence 'string?'

        public bool IsDefaultShipping { get; set; } // Assumed NOT NULL in DB (bit, 0)
        public bool IsDefaultBilling { get; set; } // Assumed NOT NULL in DB (bit, 0)

        public DateTime CreatedDate { get; set; } // Assumed NOT NULL in DB (datetime2, 0)
    }
}