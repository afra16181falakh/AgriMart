using System;

namespace AgriMartAPI.Models
{
    public class ErrorHandling
    {
        public int Id { get; set; } // Primary Key (often auto-incremented in DB)
        public string Message { get; set; } = string.Empty; // Human-readable message
        public string SystemMessage { get; set; } = string.Empty; // Full exception details
        public string Type { get; set; } = string.Empty; // Exception type name
        public string Line { get; set; } = string.Empty; // Class.Method or file:line (e.g., Controller.Method)
        public DateTime CreatedDate { get; set; }
    }
}