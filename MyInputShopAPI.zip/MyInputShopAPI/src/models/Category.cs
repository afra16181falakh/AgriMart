using System.ComponentModel.DataAnnotations; // Optional, but good for validation

namespace AgriMartAPI.Models
{
    public class Category
    {
        public int Id { get; set; } // Primary Key for Category, often auto-incremented

        [Required(ErrorMessage = "Category name is required.")]
        [StringLength(100, ErrorMessage = "Category name cannot exceed 100 characters.")]
        public string Name { get; set; } = string.Empty;

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters.")]
        public string? Description { get; set; } // Optional description
    }
}