using System.ComponentModel.DataAnnotations;

namespace AgriMartAPI.Models
{
    public class DeliveryChargeRule
    {
        public int RuleId { get; set; } // Maps to Id in DB (auto-incremented)

        [Required(ErrorMessage = "Rule Name is required.")]
        [StringLength(255, ErrorMessage = "Rule Name cannot exceed 255 characters.")]
        public string RuleName { get; set; } = string.Empty; // Crucial: This property must exist

        public decimal? MinOrderAmount { get; set; } // Maps to MinOrderValue (nullable)
        public decimal? MaxOrderAmount { get; set; } // Maps to MaxOrderValue (nullable)

        [Required(ErrorMessage = "Charge Amount is required.")]
        public decimal ChargeAmount { get; set; } // Maps to DeliveryCharge

        public bool IsActive { get; set; } // Maps to IsActive
    }
}