namespace AgriMartAPI.Models
{
    // This is likely a DTO for user input, NOT the database entity UserProfile.
    public class UserProfileRequest
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public UserProfileRequest() // Constructor to initialize non-nullable properties
        {
            Name = string.Empty;
            Email = string.Empty;
            Password = string.Empty;
        }
        // If there are other properties in your actual file, add them here.
    }
}