// --- File: AgriMartAPI/Interfaces/IAuthRepository.cs ---

using AgriMartAPI.Models;
using System;
using System.Threading.Tasks;

namespace AgriMartAPI.Interfaces
{
    public interface IAuthRepository
    {
        Task<Guid?> RegisterAsync(UserRegisterDto registerDto);
        Task<string> LoginAsync(UserLoginDto loginDto);
    }
}