using AgriMartAPI.Interfaces; // Ensure this is present
using AgriMartAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Repositories
{
    public class OrderItemRepository : IOrderItemRepository
    {
        private readonly IDBExecutor _dbExecutor;

        public OrderItemRepository(IDBExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor;
        }

        // Must match interface: Task<int> AddOrderItem(OrderItem orderItem)
        public async Task<int> AddOrderItem(OrderItem orderItem)
        {
            return await _dbExecutor.ExecuteScalarAsync<int>("sp_AddOrderItem", new
            {
                orderItem.OrderId,
                orderItem.ProductId,
                orderItem.Quantity,
                orderItem.Price
                // Add other OrderItem properties if applicable
            });
        }

        // Must match interface: Task<IEnumerable<OrderItem>> GetOrderItemsByOrderId(int orderId)
        public async Task<IEnumerable<OrderItem>> GetOrderItemsByOrderId(int orderId)
        {
            return await _dbExecutor.QueryAsync<OrderItem>("sp_GetOrderItemsByOrderId", new { OrderId = orderId });
        }
        // ... (other OrderItemRepository methods) ...
    }
}