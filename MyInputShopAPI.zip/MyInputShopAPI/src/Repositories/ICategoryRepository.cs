using AgriMartAPI.Models; // REQUIRED for Category model
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Repositories
{
    public interface ICategoryRepository
    {
        Task<List<Category>> GetAllCategories();
        Task<Category?> GetCategoryById(int id);
        Task<Category> CreateCategory(Category category); // Returns the created category (possibly with generated ID)
        Task<bool> UpdateCategory(Category category); // Returns true if updated, false if not found
        Task<bool> DeleteCategory(int id); // Returns true if deleted, false if not found
    }
}