// --- File: AgriMartAPI/Repositories/AuthRepository.cs ---

using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using Microsoft.Data.SqlClient; // CHANGED: Use Microsoft.Data.SqlClient
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using BCrypt.Net; // Install-Package BCrypt.Net-Next for password hashing

namespace AgriMartAPI.Repositories
{
    public class AuthRepository : IAuthRepository
    {
        private readonly string _connectionString;
        private readonly IConfiguration _configuration;
        private readonly IUserProfileRepository _userProfileRepository;

        public AuthRepository(IConfiguration configuration, IUserProfileRepository userProfileRepository)
        {
            // CHANGED: Explicitly check for null connection string to resolve CS8618
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                                ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
            _configuration = configuration;
            _userProfileRepository = userProfileRepository;
        }

        public async Task<Guid?> RegisterAsync(UserRegisterDto registerDto)
        {
            // 1. Check if user already exists
            var existingUser = await _userProfileRepository.GetUserProfileByEmail(registerDto.Email);
            if (existingUser != null)
            {
                return null; // User with this email already exists
            }

            // 2. Hash the password (CRITICAL SECURITY STEP!)
            // UNCOMMENTED AND CORRECTED BCrypt.Net USAGE
            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(registerDto.Password);

            // 3. Insert new user into database
            Guid newUserId = Guid.NewGuid();
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = @"INSERT INTO UserProfiles (UserId, Name, Email, PhoneNumber, PasswordHash, Role, IsActive, CreatedDate, LastLogin)
                              VALUES (@UserId, @Name, @Email, @PhoneNumber, @PasswordHash, @Role, @IsActive, @CreatedDate, @LastLogin)";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", newUserId);
                    command.Parameters.AddWithValue("@Name", registerDto.Name);
                    command.Parameters.AddWithValue("@Email", registerDto.Email);
                    command.Parameters.AddWithValue("@PhoneNumber", registerDto.PhoneNumber ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                    command.Parameters.AddWithValue("@Role", "Customer"); // Default role
                    command.Parameters.AddWithValue("@IsActive", true);
                    command.Parameters.AddWithValue("@CreatedDate", DateTime.UtcNow);
                    command.Parameters.AddWithValue("@LastLogin", (object)DBNull.Value); // Null on registration

                    var affectedRows = await command.ExecuteNonQueryAsync();
                    if (affectedRows > 0)
                    {
                        return newUserId;
                    }
                    return null; // Insertion failed
                }
            }
        }

        public async Task<string> LoginAsync(UserLoginDto loginDto)
        {
            // 1. Retrieve user by email
            // Note: GetUserProfileByEmail now returns UserProfile? (nullable)
            var user = await _userProfileRepository.GetUserProfileByEmail(loginDto.Email);
            if (user == null || user.IsActive == false) // User not found or inactive
            {
                return null;
            }

            // 2. Verify password (CRITICAL SECURITY STEP!)
            // UNCOMMENTED AND CORRECTED BCrypt.Net USAGE
            if (!BCrypt.Net.BCrypt.Verify(loginDto.Password, user.PasswordHash))
            {
                return null; // Password does not match
            }

            // 3. Update LastLogin timestamp
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var updateQuery = "UPDATE UserProfiles SET LastLogin = @LastLogin WHERE UserId = @UserId";
                using (var updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@LastLogin", DateTime.UtcNow);
                    updateCommand.Parameters.AddWithValue("@UserId", user.UserId);
                    await updateCommand.ExecuteNonQueryAsync();
                }
            }

            // 4. Generate JWT token
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["Jwt:Key"]);

            var claims = new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()), // Use GUID
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role ?? "Customer")
            });

            var tokenDescriptor = new SecurityTokenDescriptor
                            {
                Subject = claims,
                Expires = DateTime.UtcNow.AddHours(1), // Token expiration
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                Issuer = _configuration["Jwt:Issuer"],
                Audience = _configuration["Jwt:Audience"]
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}