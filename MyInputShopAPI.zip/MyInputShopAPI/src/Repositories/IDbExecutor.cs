// File: AgriMartAPI/Interfaces/IDBExecutor.cs
using System.Collections.Generic;
using System.Data; // VERY IMPORTANT: Ensure this is present
using System.Threading.Tasks;

namespace AgriMartAPI.Interfaces
{
    public interface IDBExecutor
    {
        Task<int> ExecuteAsync(string sql, object? parameters = null, CommandType commandType = CommandType.Text);
        Task<IEnumerable<T>> QueryAsync<T>(string sql, object? parameters = null, CommandType commandType = CommandType.Text);
        Task<T?> QuerySingleOrDefaultAsync<T>(string sql, object? parameters = null, CommandType commandType = CommandType.Text);
        Task<T?> ExecuteScalarAsync<T>(string sql, object? parameters = null, CommandType commandType = CommandType.Text);
    }
}