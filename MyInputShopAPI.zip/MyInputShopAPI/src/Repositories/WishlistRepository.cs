// using AgriMartAPI.Constants;
// using AgriMartAPI.models;
// using Microsoft.Data.SqlClient;
// using System.Collections.Generic;
// using System.Data;
// using System.Threading.Tasks;

// namespace AgriMartAPI.Repositories
// {
//     public class WishlistRepository : IWishlistRepository
//     {
//         private readonly IDbExecutor _dbExecutor;
//         public WishlistRepository(IDbExecutor dbExecutor) { _dbExecutor = dbExecutor; }

//         public async Task AddItem(string userId, string productId)
//         {
//             var parameters = new[] { new SqlParameter("@UserId", userId), new SqlParameter("@ProductId", productId) };
//             await _dbExecutor.ExecuteNonQueryAsync(StoredProcedureNames.Wishlist.AddItem, parameters, CommandType.StoredProcedure);
//         }

//         public async Task<bool> Clear(string userId)
//         {
//             var parameters = new[] { new SqlParameter("@UserId", userId) };
//             int rowsAffected = await _dbExecutor.ExecuteNonQueryAsync(StoredProcedureNames.Wishlist.Clear, parameters, CommandType.StoredProcedure);
//             return rowsAffected > 0;
//         }

//         public async Task<IEnumerable<Product>> GetByUserId(string userId)
//         {
//             var parameters = new[] { new SqlParameter("@UserId", userId) };
//             return await _dbExecutor.QueryAsync(StoredProcedureNames.Wishlist.GetByUserId, MapToProduct, parameters, CommandType.StoredProcedure);
//         }
        
//         // =========================================================
//         // THIS IS THE MISSING METHOD THAT IS NOW ADDED
//         // =========================================================
//         public async Task<bool> IsItemInWishlist(string userId, string productId)
//         {
//             // You need a stored procedure for this.
//             // It should return 1 if the item exists, and 0 otherwise.
//             var sql = "SELECT IIF(EXISTS(SELECT 1 FROM WishlistItems WHERE UserId = @UserId AND ProductId = @ProductId), 1, 0)";
//             var parameters = new[]
//             {
//                 new SqlParameter("@UserId", userId),
//                 new SqlParameter("@ProductId", productId)
//             };
            
//             // We use ScalarAsync to get a single value (1 or 0)
//             var result = await _dbExecutor.ScalarAsync<int>(sql, parameters);
//             return result == 1;
//         }

//         public async Task<bool> RemoveItem(string userId, string productId)
//         {
//             var parameters = new[] { new SqlParameter("@UserId", userId), new SqlParameter("@ProductId", productId) };
//             int rowsAffected = await _dbExecutor.ExecuteNonQueryAsync(StoredProcedureNames.Wishlist.RemoveItem, parameters, CommandType.StoredProcedure);
//             return rowsAffected > 0;
//         }
        
//         private Product MapToProduct(SqlDataReader reader)
//         {
//             return new Product { ProductId = reader.GetGuid(reader.GetOrdinal("ProductId")), Name = reader.GetString(reader.GetOrdinal("Name")), Description = reader.GetString(reader.GetOrdinal("Description")), Price = reader.GetDecimal(reader.GetOrdinal("Price")), StockQuantity = reader.GetInt32(reader.GetOrdinal("StockQuantity")) };
//         }
//     }
// }