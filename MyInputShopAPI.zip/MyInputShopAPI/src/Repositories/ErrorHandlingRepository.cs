using AgriMartAPI.Models;
using AgriMartAPI.Interfaces;
using System;
using System.Threading.Tasks;

namespace AgriMartAPI.Repositories
{
    public class ErrorHandlingRepository : IErrorHandlingRepository
    {
        private readonly IDBExecutor _dbExecutor;

        public ErrorHandlingRepository(IDBExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor;
        }

        public async Task CreateErrorLog(ErrorHandling errorLog)
        {
            // Ensure your SQL query matches your database table and column names
            // For example, if your table is 'ErrorLogs' and columns are 'Message', 'SystemMessage', etc.
            string insertSql = @"
                INSERT INTO dbo.ErrorLogs (
                    Message,
                    SystemMessage,
                    Type,
                    Line,
                    CreatedDate
                ) VALUES (
                    @Message,
                    @SystemMessage,
                    @Type,
                    @Line,
                    @CreatedDate
                );";

            // --- THE CRITICAL FIX IS HERE ---
            // Dapper expects parameters as an anonymous object where property names
            // match the SQL parameter names (without the '@' prefix in the C# object).
            var parameters = new
            {
                // Property names (e.g., Message) must match SQL parameter names (e.g., @Message)
                Message = errorLog.Message,
                SystemMessage = errorLog.SystemMessage,
                Type = errorLog.Type,
                Line = errorLog.Line,
                CreatedDate = errorLog.CreatedDate
            };

            // _dbExecutor.ExecuteAsync will correctly pass this anonymous object to Dapper
            await _dbExecutor.ExecuteAsync(insertSql, parameters);
        }
    }
}