// using AgriMartAPI.Constants;
// using AgriMartAPI.models;
// using Microsoft.Data.SqlClient;
// using System.Collections.Generic;
// using System.Data;
// using System.Threading.Tasks;

// namespace AgriMartAPI.Repositories
// {
//     public class PaymentMethodRepository : IPaymentMethodRepository
//     {
//         private readonly IDbExecutor _dbExecutor;
//         public PaymentMethodRepository(IDbExecutor dbExecutor) { _dbExecutor = dbExecutor; }
        
//         public async Task<IEnumerable<PaymentMethod>> GetAll()
//         {
//             return await _dbExecutor.QueryAsync(StoredProcedureNames.PaymentMethods.GetAll, MapToPaymentMethod, commandType: CommandType.StoredProcedure);
//         }

//         private PaymentMethod MapToPaymentMethod(SqlDataReader reader)
//         {
//             return new PaymentMethod { PaymentMethodId = reader.GetInt32(reader.GetOrdinal("PaymentMethodId")), Name = reader.GetString(reader.GetOrdinal("Name")), IsEnabled = reader.GetBoolean(reader.GetOrdinal("IsEnabled")) };
//         }
//     }
// }