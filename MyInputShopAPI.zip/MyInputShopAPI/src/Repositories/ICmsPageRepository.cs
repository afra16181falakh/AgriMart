using System;
using System.Threading.Tasks;
using AgriMartAPI.Models;

namespace AgriMartAPI.Interfaces
{
    public interface ICmsPageRepository
    {
        Task<CmsPage?> GetCmsPageBySlug(string slug);
        Task<Guid> CreateCmsPage(CmsPage page, Guid userId);
        Task<bool> UpdateCmsPage(CmsPage page, Guid userId, DateTime modifiedDate);
        Task<bool> DeleteCmsPage(Guid id); // Signature remains the same
    }
}