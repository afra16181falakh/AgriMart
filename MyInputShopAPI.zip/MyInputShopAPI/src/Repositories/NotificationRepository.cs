// File: src/AgriMartAPI/Repositories/NotificationRepository.cs

using AgriMartAPI.Models;         // REQUIRED: For the Notification model
using AgriMartAPI.Interfaces;     // REQUIRED: For IDBExecutor and INotificationRepository
using Microsoft.Data.SqlClient;   // For SqlParameter and SqlDataReader
using System;                     // For Guid, DateTime, ArgumentException, DBNull
using System.Collections.Generic; // For List<T>, IEnumerable<T>
using System.Threading.Tasks;     // For Task

namespace AgriMartAPI.Repositories
{
    public class NotificationRepository : INotificationRepository
    {
        private readonly IDBExecutor _dbExecutor; // Using the correct casing IDBExecutor

        // Constructor to inject the DBExecutor
        public NotificationRepository(IDBExecutor dbExecutor) // Using the correct casing IDBExecutor
        {
            _dbExecutor = dbExecutor;
        }

        // Method to create a new notification record
        public async Task Create(Notification notification)
        {
            if (notification == null || notification.UserId == Guid.Empty || string.IsNullOrWhiteSpace(notification.Message))
            {
                throw new ArgumentException("Invalid notification data provided.");
            }

            var parameters = new SqlParameter[]
            {
                new SqlParameter("@UserId", notification.UserId),
                new SqlParameter("@Message", notification.Message),
                new SqlParameter("@DateSent", notification.DateSent == DateTime.MinValue ? DateTime.UtcNow : notification.DateSent), // Default to UtcNow if not set
                new SqlParameter("@IsRead", notification.IsRead)
            };

            // Assuming NotificationId is auto-incremented by the database
            string sql = @"INSERT INTO dbo.Notifications (UserId, Message, DateSent, IsRead)
                           VALUES (@UserId, @Message, @DateSent, @IsRead);";

            await _dbExecutor.ExecuteAsync(sql, parameters);
        }

        // Method to retrieve notifications for a specific user
        public async Task<IEnumerable<Notification>> GetByUserId(Guid userId)
        {
            if (userId == Guid.Empty)
            {
                throw new ArgumentException("UserId cannot be an empty GUID.");
            }

            var parameters = new SqlParameter[] { new SqlParameter("@UserId", userId) };

            string sql = @"SELECT NotificationId, UserId, Message, DateSent, IsRead
                           FROM dbo.Notifications
                           WHERE UserId = @UserId
                           ORDER BY DateSent DESC;"; // Order by most recent first

            var notifications = await _dbExecutor.QueryAsync<Notification>(sql, parameters);
            return notifications;
        }

        // Method to mark a notification as read
        public async Task MarkAsRead(int notificationId)
        {
            if (notificationId <= 0)
            {
                throw new ArgumentException("NotificationId must be a positive integer.");
            }

            var parameters = new SqlParameter[] { new SqlParameter("@NotificationId", notificationId) };

            string sql = @"UPDATE dbo.Notifications
                           SET IsRead = 1
                           WHERE NotificationId = @NotificationId AND IsRead = 0;"; // Only update if not already read

            await _dbExecutor.ExecuteAsync(sql, parameters);
        }

        // Method to delete a notification
        public async Task Delete(int notificationId)
        {
            if (notificationId <= 0)
            {
                throw new ArgumentException("NotificationId must be a positive integer for deletion.");
            }

            var parameters = new SqlParameter[] { new SqlParameter("@NotificationId", notificationId) };

            string sql = "DELETE FROM dbo.Notifications WHERE NotificationId = @NotificationId;";

            await _dbExecutor.ExecuteAsync(sql, parameters);
        }
    }
}