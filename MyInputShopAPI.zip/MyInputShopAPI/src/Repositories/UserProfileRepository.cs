// --- File: AgriMartAPI/Repositories/UserProfileRepository.cs ---

using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Threading.Tasks;

namespace AgriMartAPI.Repositories
{
    public class UserProfileRepository : IUserProfileRepository
    {
        private readonly string _connectionString;

        public UserProfileRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                                ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
        }

        public async Task<UserProfile?> GetUserProfileByEmail(string email)
        {
            return await GetUserByField("Email", email);
        }

        // --- FIX: Added implementation for GetUserProfileById ---
        public async Task<UserProfile?> GetUserProfileById(Guid userId)
        {
            return await GetUserByField("UserId", userId);
        }

        // --- FIX: Added implementation for GetUserProfileByPhoneNumber ---
        public async Task<UserProfile?> GetUserProfileByPhoneNumber(string phoneNumber)
        {
            return await GetUserByField("PhoneNumber", phoneNumber);
        }

        public async Task<IEnumerable<UserProfile>> GetAllUserProfiles()
        {
            var userProfiles = new List<UserProfile>();
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = "SELECT UserId, Name, Email, PhoneNumber, PasswordHash, Role, IsActive, CreatedDate, LastLogin FROM UserProfiles";
                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            userProfiles.Add(MapUserProfileFromReader(reader));
                        }
                    }
                }
            }
            return userProfiles;
        }
        
        // --- FIX: Added implementation for CreateUserProfile ---
        public async Task<Guid?> CreateUserProfile(UserProfile profile)
        {
            profile.UserId = Guid.NewGuid(); // Ensure a new Guid is created
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = @"INSERT INTO UserProfiles (UserId, Name, Email, PhoneNumber, PasswordHash, Role, IsActive, CreatedDate, LastLogin)
                              VALUES (@UserId, @Name, @Email, @PhoneNumber, @PasswordHash, @Role, @IsActive, @CreatedDate, @LastLogin)";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", profile.UserId);
                    command.Parameters.AddWithValue("@Name", profile.Name);
                    command.Parameters.AddWithValue("@Email", profile.Email);
                    command.Parameters.AddWithValue("@PhoneNumber", profile.PhoneNumber);
                    command.Parameters.AddWithValue("@PasswordHash", profile.PasswordHash);
                    command.Parameters.AddWithValue("@Role", profile.Role);
                    command.Parameters.AddWithValue("@IsActive", profile.IsActive);
                    command.Parameters.AddWithValue("@CreatedDate", profile.CreatedDate);
                    command.Parameters.AddWithValue("@LastLogin", profile.LastLogin ?? (object)DBNull.Value);

                    var affectedRows = await command.ExecuteNonQueryAsync();
                    return affectedRows > 0 ? profile.UserId : null;
                }
            }
        }
        
        public async Task<bool> UpdateUserProfile(UserProfile userProfile)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = @"UPDATE UserProfiles SET
                                Name = @Name, Email = @Email, PhoneNumber = @PhoneNumber,
                                Role = @Role, IsActive = @IsActive
                              WHERE UserId = @UserId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Name", userProfile.Name);
                    command.Parameters.AddWithValue("@Email", userProfile.Email);
                    command.Parameters.AddWithValue("@PhoneNumber", userProfile.PhoneNumber);
                    command.Parameters.AddWithValue("@Role", userProfile.Role);
                    command.Parameters.AddWithValue("@IsActive", userProfile.IsActive);
                    command.Parameters.AddWithValue("@UserId", userProfile.UserId);
                    return await command.ExecuteNonQueryAsync() > 0;
                }
            }
        }

        public async Task<bool> DeleteUserProfile(Guid userId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = "DELETE FROM UserProfiles WHERE UserId = @UserId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    return await command.ExecuteNonQueryAsync() > 0;
                }
            }
        }

        public async Task<int> GetUserCount()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = "SELECT COUNT(*) FROM UserProfiles";
                using (var command = new SqlCommand(query, connection))
                {
                    return (int)(await command.ExecuteScalarAsync())!;
                }
            }
        }

        // Helper method to avoid code duplication
        private async Task<UserProfile?> GetUserByField(string fieldName, object value)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var query = $"SELECT UserId, Name, Email, PhoneNumber, PasswordHash, Role, IsActive, CreatedDate, LastLogin FROM UserProfiles WHERE {fieldName} = @Value";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Value", value);
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return MapUserProfileFromReader(reader);
                        }
                    }
                }
            }
            return null;
        }

        private UserProfile MapUserProfileFromReader(SqlDataReader reader)
        {
            return new UserProfile
            {
                UserId = reader.GetGuid(reader.GetOrdinal("UserId")),
                Name = reader.GetString(reader.GetOrdinal("Name")),
                Email = reader.GetString(reader.GetOrdinal("Email")),
                PhoneNumber = reader.GetString(reader.GetOrdinal("PhoneNumber")),
                PasswordHash = reader.GetString(reader.GetOrdinal("PasswordHash")),
                Role = reader.GetString(reader.GetOrdinal("Role")),
                IsActive = reader.GetBoolean(reader.GetOrdinal("IsActive")),
                CreatedDate = reader.GetDateTime(reader.GetOrdinal("CreatedDate")),
                LastLogin = reader.IsDBNull(reader.GetOrdinal("LastLogin")) ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("LastLogin"))
            };
        }
    }
}