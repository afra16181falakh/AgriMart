// --- File: AgriMartAPI/Interfaces/IUserProfileRepository.cs ---

using AgriMartAPI.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Interfaces
{
    public interface IUserProfileRepository
    {
        Task<UserProfile?> GetUserProfileByEmail(string email);
        Task<IEnumerable<UserProfile>> GetAllUserProfiles();
        Task<bool> UpdateUserProfile(UserProfile userProfile);
        Task<bool> DeleteUserProfile(Guid userId);
        Task<int> GetUserCount();

        // --- FIX: Added missing method definitions required by controllers and services ---
        Task<UserProfile?> GetUserProfileById(Guid userId);
        Task<Guid?> CreateUserProfile(UserProfile profile);
        Task<UserProfile?> GetUserProfileByPhoneNumber(string phoneNumber);
    }
}