// src/AgriMartAPI/Repositories/CategoryRepository.cs
using AgriMartAPI.Models; // Required for Category model
using AgriMartAPI.Interfaces; // Required for IDBExecutor
// REMOVE THIS LINE: using Microsoft.Data.SqlClient; // Not needed if using Dapper-style parameters
using System; // For DBNull
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq; // Added for ToList()

namespace AgriMartAPI.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly IDBExecutor _dbExecutor;

        public CategoryRepository(IDBExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor;
        }

        public async Task<List<Category>> GetAllCategories()
        {
            // Parameters are null here, so no change needed (Dapper handles null correctly)
            var categories = await _dbExecutor.QueryAsync<Category>("SELECT Id, Name, Description FROM dbo.Category", null);
            return categories.ToList();
        }

        public async Task<Category?> GetCategoryById(int id)
        {
            // FIX: Changed from SqlParameter[] to anonymous object
            var parameters = new { Id = id }; // Property name 'Id' matches @Id in SQL
            var category = await _dbExecutor.QuerySingleOrDefaultAsync<Category>("SELECT Id, Name, Description FROM dbo.Category WHERE Id = @Id", parameters);
            return category;
        }

        public async Task<Category> CreateCategory(Category category)
        {
            // FIX: Changed from SqlParameter[] to anonymous object
            var parameters = new
            {
                Name = category.Name,
                Description = category.Description // Dapper handles null strings naturally; DBNull.Value is usually not needed here
            };

            // Use SCOPE_IDENTITY() to get the auto-generated ID
            string sql = "INSERT INTO dbo.Category (Name, Description) VALUES (@Name, @Description); SELECT SCOPE_IDENTITY();";
            object? newId = await _dbExecutor.ExecuteScalarAsync<object>(sql, parameters);

            category.Id = Convert.ToInt32(newId); // Assign the generated ID back to the category object
            return category;
        }

        public async Task<bool> UpdateCategory(Category category)
        {
            // FIX: Changed from SqlParameter[] to anonymous object
            var parameters = new
            {
                Id = category.Id,
                Name = category.Name,
                Description = category.Description // Dapper handles null strings naturally
            };
            int rowsAffected = await _dbExecutor.ExecuteAsync(
                "UPDATE dbo.Category SET Name=@Name, Description=@Description WHERE Id=@Id", parameters);
            return rowsAffected > 0;
        }

        public async Task<bool> DeleteCategory(int id)
        {
            // FIX: Changed from SqlParameter[] to anonymous object
            var parameters = new { Id = id }; // Property name 'Id' matches @Id in SQL
            int rowsAffected = await _dbExecutor.ExecuteAsync("DELETE FROM dbo.Category WHERE Id = @Id", parameters);
            return rowsAffected > 0;
        }
    }
}