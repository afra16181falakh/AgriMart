using AgriMartAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Interfaces
{
    public interface IDeliveryChargeRulesRepository
    {
        Task<IEnumerable<DeliveryChargeRule>> GetAllDeliveryChargeRules();

        // CHANGED: Accept DeliveryChargeRule model directly for add/update
        Task<int> AddDeliveryChargeRule(DeliveryChargeRule rule);
        Task<bool> UpdateDeliveryChargeRule(DeliveryChargeRule rule);

        Task<bool> DeleteDeliveryChargeRule(int ruleId);
    }
}