// using AgriMartAPI.Constants;
// using AgriMartAPI.models;
// using Microsoft.Data.SqlClient;
// using System;
// using System.Collections.Generic;
// using System.Data;
// using System.Threading.Tasks;

// namespace AgriMartAPI.Repositories
// {
//     public class ProductReviewRepository : IProductReviewRepository
//     {
//         private readonly IDbExecutor _dbExecutor;
//         public ProductReviewRepository(IDbExecutor dbExecutor) { _dbExecutor = dbExecutor; }
        
//         public async Task<ProductReview> Create(ProductReview review)
//         {
//             var parameters = new[] { new SqlParameter("@ProductId", review.ProductId), new SqlParameter("@UserId", review.UserId), new SqlParameter("@Rating", review.Rating), new SqlParameter("@Comment", review.Comment) };
//             await _dbExecutor.ExecuteNonQueryAsync(StoredProcedureNames.ProductReviews.Create, parameters, CommandType.StoredProcedure);
//             // The Id is an IDENTITY column, so we don't know it until after insert.
//             // For simplicity, we return the object without the new Id. A more complex implementation might return it.
//             return review;
//         }

//         public async Task<bool> Delete(int reviewId)
//         {
//             var parameters = new[] { new SqlParameter("@ReviewId", reviewId) };
//             int rowsAffected = await _dbExecutor.ExecuteNonQueryAsync(StoredProcedureNames.ProductReviews.Delete, parameters, CommandType.StoredProcedure);
//             return rowsAffected > 0;
//         }

//         public async Task<IEnumerable<ProductReview>> GetByProductId(Guid productId)
//         {
//             var parameters = new[] { new SqlParameter("@ProductId", productId) };
//             return await _dbExecutor.QueryAsync(StoredProcedureNames.ProductReviews.GetByProductId, MapToProductReview, parameters, CommandType.StoredProcedure);
//         }

//         private ProductReview MapToProductReview(SqlDataReader reader)
//         {
//             return new ProductReview { ReviewId = reader.GetInt32(reader.GetOrdinal("ReviewId")), ProductId = reader.GetGuid(reader.GetOrdinal("ProductId")), UserId = reader.GetGuid(reader.GetOrdinal("UserId")), Rating = reader.GetInt32(reader.GetOrdinal("Rating")), Comment = reader.GetString(reader.GetOrdinal("Comment")), CreatedDate = reader.GetDateTime(reader.GetOrdinal("CreatedDate")), UserName = reader.GetString(reader.GetOrdinal("UserName")) };
//         }
//     }
// }