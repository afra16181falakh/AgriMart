using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using System.Threading.Tasks;
using System.Data; // Required for CommandType
using System;     // Required for Guid
using System.Linq; // For .ToList() if used in other methods

namespace AgriMartAPI.Repositories
{
    public class CmsPageRepository : ICmsPageRepository
    {
        private readonly IDBExecutor _dbExecutor;

        public CmsPageRepository(IDBExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor;
        }

        public async Task<CmsPage?> GetCmsPageBySlug(string slug)
        {
            return await _dbExecutor.QuerySingleOrDefaultAsync<CmsPage>(
                "sp_GetCmsPageBySlug",
                new { Slug = slug },
                commandType: CommandType.StoredProcedure
            );
        }

        public async Task<Guid> CreateCmsPage(CmsPage page, Guid userId)
        {
            Guid newId = await _dbExecutor.ExecuteScalarAsync<Guid>(
                "sp_CreateCmsPage",
                new
                {
                    page.Title,
                    page.Slug,
                    ContentHtml = page.ContentHtml,
                    IsPublished = page.IsPublished,
                    UserId = userId
                },
                commandType: CommandType.StoredProcedure
            );
            return newId;
        }

        public async Task<bool> UpdateCmsPage(CmsPage page, Guid userId, DateTime modifiedDate)
        {
            Console.WriteLine($"[DEBUG] CmsPageRepository.Update: Incoming page.Id = {page.Id}");
            Console.WriteLine($"[DEBUG] CmsPageRepository.Update: Incoming page.Title = {page.Title}");
            Console.WriteLine($"[DEBUG] CmsPageRepository.Update: Incoming page.Slug = {page.Slug}");
            Console.WriteLine($"[DEBUG] CmsPageRepository.Update: Incoming page.ContentHtml = {page.ContentHtml}");
            Console.WriteLine($"[DEBUG] CmsPageRepository.Update: Incoming page.IsPublished = {page.IsPublished}");
            Console.WriteLine($"[DEBUG] CmsPageRepository.Update: Incoming userId = {userId}");
            Console.WriteLine($"[DEBUG] CmsPageRepository.Update: Incoming modifiedDate = {modifiedDate}");

            var affectedRows = await _dbExecutor.ExecuteScalarAsync<int>(
                "sp_UpdateCmsPage",
                new
                {
                    Id = page.Id,
                    page.Title,
                    page.Slug,
                    ContentHtml = page.ContentHtml,
                    IsPublished = page.IsPublished,
                    ModifiedByUserId = userId,
                    ModifiedDate = modifiedDate
                },
                commandType: CommandType.StoredProcedure
            );

            Console.WriteLine($"[DEBUG] CmsPageRepository.Update: Stored procedure returned {affectedRows} affected rows.");

            return affectedRows > 0;
        }

        // --- CRITICAL MODIFICATIONS FOR DELETE METHOD ---
        public async Task<bool> DeleteCmsPage(Guid id)
        {
            // ADDED DEBUG LINE: Confirming ID received for deletion
            Console.WriteLine($"[DEBUG] CmsPageRepository.Delete: Attempting to delete Id = {id}");

            // CRITICAL CHANGE: Use ExecuteScalarAsync<int> for DELETE
            // This ensures Dapper explicitly captures the RowsAffected returned by the SP.
            var affectedRows = await _dbExecutor.ExecuteScalarAsync<int>( // <--- THIS IS THE FIX
                "sp_DeleteCmsPage",
                new { Id = id },
                commandType: CommandType.StoredProcedure
            );

            // ADDED DEBUG LINE: Logging the affected rows from the stored procedure
            Console.WriteLine($"[DEBUG] CmsPageRepository.Delete: Stored procedure returned {affectedRows} affected rows.");

            return affectedRows > 0;
        }
    }
}