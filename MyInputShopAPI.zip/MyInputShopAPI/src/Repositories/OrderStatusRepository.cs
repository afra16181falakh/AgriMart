using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Repositories
{
    public class OrderStatusRepository : IOrderStatusRepository
    {
        private readonly IDBExecutor _dbExecutor;

        public OrderStatusRepository(IDBExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor;
        }

        public async Task<IEnumerable<OrderStatus>> GetAllOrderStatusAsync()
        {
            // Note: The stored procedure 'Sp_GetAllOrderStatus' needs to be created in your database.
            // It should return Id, StatusName, and Description for all order statuses.
            
            // CORRECTED LINE 21:
            // Changed 'null' to 'new {}' for the parameters argument.
            // This is safer as some custom wrappers for database execution don't handle null parameter objects gracefully.
            return await _dbExecutor.QueryAsync<OrderStatus>("Sp_GetAllOrderStatus", new {});
        }
    }
}