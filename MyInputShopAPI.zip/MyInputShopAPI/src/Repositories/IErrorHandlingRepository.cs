using AgriMartAPI.Models;
using System.Threading.Tasks;

namespace AgriMartAPI.Repositories
{
    public interface IErrorHandlingRepository
    {
        Task CreateErrorLog(ErrorHandling errorLog);
    }
}