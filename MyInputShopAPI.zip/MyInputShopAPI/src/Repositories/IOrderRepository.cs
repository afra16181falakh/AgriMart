// --- File: AgriMartAPI/Interfaces/IOrderRepository.cs ---
using AgriMartAPI.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Interfaces
{
    public interface IOrderRepository
    {
        Task<IEnumerable<Order>> GetAll();
        Task<Order?> GetById(Guid id); // Parameter type is Guid
        Task<Guid> Create(Order order); // Returns Guid, as Id is Guid
        Task<bool> Update(Order order);
        Task<bool> Delete(Guid id); // Parameter type is Guid
        Task<int> GetTotalOrderCount();
        Task<decimal> GetTotalRevenue();
    }
}