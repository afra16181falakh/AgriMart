// src/AgriMartAPI/Repositories/IAddressRepository.cs
using AgriMartAPI.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Repositories
{
    public interface IAddressRepository
    {
        Task<Address> CreateAddress(Address address);
        Task<List<Address>> GetAddressByUserId(Guid userId, int pageNumber, int pageSize);
        Task<Address?> GetAddressById(int addressId);
        Task<bool> UpdateAddress(Address address);
        Task<bool> DeleteAddress(int addressId);
    }
}