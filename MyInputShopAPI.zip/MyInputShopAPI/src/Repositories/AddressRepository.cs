using AgriMartAPI.Models;
using AgriMartAPI.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AgriMartAPI.Repositories
{
    public class AddressRepository : IAddressRepository
    {
        private readonly IDBExecutor _dbExecutor;

        public AddressRepository(IDBExecutor dbExecutor)
        {
            _dbExecutor = dbExecutor;
        }

        public async Task<Address> CreateAddress(Address address)
        {
            // FIX: Include ALL columns from dbo.Address table in the INSERT statement
            string insertSql = @"
                INSERT INTO dbo.Address (
                    UserId, Street, City, State, ZipCode,
                    AddressLine1, AddressLine2, Country, FullName, PhoneNumber,
                    IsDefaultShipping, IsDefaultBilling, CreatedDate
                )
                VALUES (
                    @UserId, @Street, @City, @State, @ZipCode,
                    @AddressLine1, @AddressLine2, @Country, @FullName, @PhoneNumber,
                    @IsDefaultShipping, @IsDefaultBilling, @CreatedDate
                );
                SELECT SCOPE_IDENTITY();"; // Retrieve the last identity value inserted into an identity column

            // FIX: Pass ALL corresponding parameters, mapping C# properties to SQL parameters
            var parameters = new
            {
                UserId = address.UserId,
                Street = address.Street,
                City = address.City,
                State = address.State,
                ZipCode = address.ZipCode,
                AddressLine1 = address.AddressLine1,
                AddressLine2 = address.AddressLine2,
                Country = address.Country,
                FullName = address.FullName,
                PhoneNumber = address.PhoneNumber,
                IsDefaultShipping = address.IsDefaultShipping,
                IsDefaultBilling = address.IsDefaultBilling,
                CreatedDate = address.CreatedDate == DateTime.MinValue ? DateTime.UtcNow : address.CreatedDate // Ensure CreatedDate is not MinValue
            };

            object? newId = await _dbExecutor.ExecuteScalarAsync<object>(insertSql, parameters);
            address.AddressId = Convert.ToInt32(newId);

            return address;
        }

        public async Task<Address?> GetAddressById(int addressId)
        {
            // FIX: Select ALL columns from dbo.Address, and alias 'Id' to 'AddressId'
            var parameters = new { AddressId = addressId }; // Parameter for the WHERE clause
            var address = await _dbExecutor.QuerySingleOrDefaultAsync<Address>(@"
                SELECT
                    Id AS AddressId, UserId, Street, City, State, ZipCode,
                    AddressLine1, AddressLine2, Country, FullName, PhoneNumber,
                    IsDefaultShipping, IsDefaultBilling, CreatedDate
                FROM dbo.Address
                WHERE Id = @AddressId", parameters); // Use 'Id' for the WHERE clause matching DB
            return address;
        }

        public async Task<List<Address>> GetAddressByUserId(Guid userId, int pageNumber, int pageSize)
        {
            List<Address> addresses = new List<Address>();
            var parameters = new
            {
                UserId = userId,
                Offset = (pageNumber - 1) * pageSize,
                PageSize = pageSize
            };

            // FIX: Select ALL columns from dbo.Address, and alias 'Id' to 'AddressId'
            string sql = @"
                SELECT
                    Id AS AddressId, UserId, Street, City, State, ZipCode,
                    AddressLine1, AddressLine2, Country, FullName, PhoneNumber,
                    IsDefaultShipping, IsDefaultBilling, CreatedDate
                FROM dbo.Address
                WHERE UserId = @UserId
                ORDER BY Id
                OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";

            var results = await _dbExecutor.QueryAsync<Address>(sql, parameters);
            addresses.AddRange(results);
            return addresses;
        }

        public async Task<bool> UpdateAddress(Address address)
        {
            // FIX: Include ALL updatable columns in the SET clause
            var parameters = new
            {
                // Use 'Id' here as the parameter name for the DB column
                Id = address.AddressId,
                UserId = address.UserId, // Used in WHERE clause
                Street = address.Street,
                City = address.City,
                State = address.State,
                ZipCode = address.ZipCode,
                AddressLine1 = address.AddressLine1,
                AddressLine2 = address.AddressLine2,
                Country = address.Country,
                FullName = address.FullName,
                PhoneNumber = address.PhoneNumber,
                IsDefaultShipping = address.IsDefaultShipping,
                IsDefaultBilling = address.IsDefaultBilling,
                CreatedDate = address.CreatedDate // Assuming you might update this, or just pass it back
            };

            int rowsAffected = await _dbExecutor.ExecuteAsync(@"
                UPDATE dbo.Address
                SET
                    Street=@Street, City=@City, State=@State, ZipCode=@ZipCode,
                    AddressLine1=@AddressLine1, AddressLine2=@AddressLine2,
                    Country=@Country, FullName=@FullName, PhoneNumber=@PhoneNumber,
                    IsDefaultShipping=@IsDefaultShipping, IsDefaultBilling=@IsDefaultBilling,
                    CreatedDate=@CreatedDate
                WHERE Id=@Id AND UserId=@UserId", parameters); // Use 'Id' in WHERE clause matching DB PK

            return rowsAffected > 0;
        }

        public async Task<bool> DeleteAddress(int addressId)
        {
            // FIX: Use 'Id' as the parameter name for the DB column
            var parameters = new { Id = addressId }; // Matches DB column name
            int rowsAffected = await _dbExecutor.ExecuteAsync("DELETE FROM dbo.Address WHERE Id = @Id", parameters);
            return rowsAffected > 0;
        }
    }
}