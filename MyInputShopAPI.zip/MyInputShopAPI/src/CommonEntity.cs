using System.Collections.Generic;

namespace AgriMartAPI
{
    public class ECJsonResult
    {
        public bool IsSuccess { get; set; }
        public string? ErrorMsg { get; set; }
        public string? ErrorCode { get; set; }
        public object? Result { get; set; }
        public List<string>? ErrorList { get; set; }

        public static ECJsonResult Success()
        {
            return new ECJsonResult { IsSuccess = true };
        }

        public static ECJsonResult<T> Success<T>(T data)
        {
            return new ECJsonResult<T> { IsSuccess = true, Result = data };
        }

        public static ECJsonResult Failure(string errorMessage, string? errorCode = null)
        {
            return new ECJsonResult { IsSuccess = false, ErrorMsg = errorMessage, ErrorCode = errorCode };
        }

        public static ECJsonResult<T> Failure<T>(string errorMessage, string? errorCode = null)
        {
            return new ECJsonResult<T> { IsSuccess = false, ErrorMsg = errorMessage, ErrorCode = errorCode };
        }

        public static ECJsonResult Failure(List<string> errorList, string? errorCode = null)
        {
            return new ECJsonResult { IsSuccess = false, ErrorList = errorList, ErrorMsg = "Multiple errors occurred." };
        }
    }

    public class ECJsonResult<T> : ECJsonResult
    {
        public new T? Result { get; set; }
    }
}