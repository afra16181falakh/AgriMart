using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace AgriMartAPI.Controllers
{
    public class GenerateOtpRequest
    {
        public string Identifier { get; set; } = string.Empty;  // Typically phone number
    }

    public class VerifyOtpRequest
    {
        public string Identifier { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
    }

    [Route("api/[controller]")]
    [ApiController]
    public class OtpController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public OtpController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost("generate")]
        public async Task<IActionResult> GenerateOtp([FromBody] GenerateOtpRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Identifier))
                return BadRequest("Identifier is required.");

            string otpCode = new Random().Next(100000, 999999).ToString("D6");
            DateTime expiryTime = DateTime.UtcNow.AddMinutes(5);

            Console.WriteLine($"[OTP] For {request.Identifier}: {otpCode}");

            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            await using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();

            // Clean old OTPs
            string deleteSql = "DELETE FROM Otps WHERE Identifier = @Identifier";
            await using (var deleteCmd = new SqlCommand(deleteSql, connection))
            {
                deleteCmd.Parameters.AddWithValue("@Identifier", request.Identifier);
                await deleteCmd.ExecuteNonQueryAsync();
            }

            // Insert new OTP
            string insertSql = "INSERT INTO Otps (Identifier, Code, ExpiryTime) VALUES (@Identifier, @Code, @ExpiryTime)";
            await using (var insertCmd = new SqlCommand(insertSql, connection))
            {
                insertCmd.Parameters.AddWithValue("@Identifier", request.Identifier);
                insertCmd.Parameters.AddWithValue("@Code", otpCode);
                insertCmd.Parameters.AddWithValue("@ExpiryTime", expiryTime);
                await insertCmd.ExecuteNonQueryAsync();
            }

            // --- Twilio SMS Send ---
            try
            {
                var accountSid = _configuration["Twilio:AccountSid"];
                var authToken = _configuration["Twilio:AuthToken"];
                var fromPhone = _configuration["Twilio:FromPhone"];

                TwilioClient.Init(accountSid, authToken);

                var message = await MessageResource.CreateAsync(
                    body: $"Your AgriMart OTP is: {otpCode}",
                    from: new Twilio.Types.PhoneNumber(fromPhone),
                    to: new Twilio.Types.PhoneNumber(request.Identifier)
                );

                Console.WriteLine($"[Twilio] Sent OTP SMS. SID: {message.Sid}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Twilio] Failed: {ex.Message}");
            }

            return Ok(new { message = "OTP has been generated and sent." });
        }

        [HttpPost("verify")]
        public async Task<IActionResult> VerifyOtp([FromBody] VerifyOtpRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Identifier) || string.IsNullOrWhiteSpace(request.Code))
                return BadRequest("Identifier and code are required.");

            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            await using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();

            string selectSql = "SELECT Code, ExpiryTime FROM Otps WHERE Identifier = @Identifier";
            string? dbCode = null;
            DateTime? dbExpiry = null;

            await using (var selectCmd = new SqlCommand(selectSql, connection))
            {
                selectCmd.Parameters.AddWithValue("@Identifier", request.Identifier);
                await using var reader = await selectCmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    dbCode = reader.GetString(0);
                    dbExpiry = reader.GetDateTime(1);
                }
            }

            if (dbCode == null || dbExpiry == null)
                return BadRequest(new { isValid = false, message = "Invalid identifier or OTP." });

            if (dbExpiry < DateTime.UtcNow)
                return BadRequest(new { isValid = false, message = "OTP has expired." });

            if (dbCode != request.Code)
                return BadRequest(new { isValid = false, message = "Incorrect OTP." });

            // OTP valid — remove it
            string deleteSql = "DELETE FROM Otps WHERE Identifier = @Identifier";
            await using (var deleteCmd = new SqlCommand(deleteSql, connection))
            {
                deleteCmd.Parameters.AddWithValue("@Identifier", request.Identifier);
                await deleteCmd.ExecuteNonQueryAsync();
            }

            return Ok(new { isValid = true, message = "OTP verified successfully." });
        }
    }
}