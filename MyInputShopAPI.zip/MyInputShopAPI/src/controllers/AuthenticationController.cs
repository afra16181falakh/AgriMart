// --- File: AgriMartAPI/Controllers/AuthenticationController.cs ---

using AgriMartAPI.Interfaces;
using AgriMartAPI.Models; // For UserLoginDto, UserRegisterDto
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace AgriMartAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthenticationController : ControllerBase
    {
        private readonly IAuthRepository _authRepo;
        private readonly ILogger<AuthenticationController> _logger;

        public AuthenticationController(IAuthRepository authRepo, ILogger<AuthenticationController> logger)
        {
            _authRepo = authRepo;
            _logger = logger;
        }

        [AllowAnonymous]
        [HttpPost("register")] // POST /api/Authentication/register
        public async Task<IActionResult> Register([FromBody] UserRegisterDto registerDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var result = await _authRepo.RegisterAsync(registerDto);
                if (result == null)
                {
                    return BadRequest("Registration failed: User already exists or invalid data.");
                }
                return Ok(new { Message = "Registration successful", UserId = result });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Registration failed for email: {Email}", registerDto.Email);
                return StatusCode(500, "Internal server error during registration.");
            }
        }

        [AllowAnonymous]
        [HttpPost("login")] // POST /api/Authentication/login
        public async Task<IActionResult> Login([FromBody] UserLoginDto loginDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var token = await _authRepo.LoginAsync(loginDto);
                if (string.IsNullOrEmpty(token))
                {
                    return Unauthorized("Invalid credentials.");
                }
                return Ok(new { Token = token });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Login failed for email: {Email}", loginDto.Email);
                return StatusCode(500, "Internal server error during login.");
            }
        }
    }
}