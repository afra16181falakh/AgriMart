// using AgriMartAPI.Repositories;
// using Microsoft.AspNetCore.Mvc;
// using Microsoft.Extensions.Logging;
// using System;
// using System.Threading.Tasks;

// namespace AgriMartAPI.Controllers
// {
//     [Route("api/[controller]")]
//     [ApiController]
//     public class PromotionsController : ControllerBase
//     {
//         private readonly IPromotionRepository _promotionRepo;
//         private readonly ILogger<PromotionsController> _logger;

//         public PromotionsController(IPromotionRepository promotionRepo, ILogger<PromotionsController> logger)
//         {
//             _promotionRepo = promotionRepo;
//             _logger = logger;
//         }

//         [HttpGet]
//         public async Task<IActionResult> GetActivePromotions()
//         {
//             try
//             {
//                 var promotions = await _promotionRepo.GetAllActive();
//                 return Ok(promotions);
//             }
//             catch (Exception ex)
//             {
//                 _logger.LogError(ex, "Error fetching active promotions.");
//                 return StatusCode(500, "An internal server error occurred.");
//             }
//         }

//         [HttpGet("{code}")]
//         public async Task<IActionResult> GetPromotionByCode(string code)
//         {
//             try
//             {
//                 var promotion = await _promotionRepo.GetByCode(code);
//                 if (promotion == null) return NotFound();
//                 return Ok(promotion);
//             }
//             catch (Exception ex)
//             {
//                 _logger.LogError(ex, "Error fetching promotion with code {PromoCode}", code);
//                 return StatusCode(500, "An internal server error occurred.");
//             }
//         }
//     }
// }