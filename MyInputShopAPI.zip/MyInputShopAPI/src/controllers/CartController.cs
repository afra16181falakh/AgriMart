// --- File: AgriMartAPI/Controllers/CartController.cs ---

using AgriMartAPI.Models;
using AgriMartAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Security.Claims;
using System.Threading.Tasks;
using System.IdentityModel.Tokens.Jwt; // Make sure this is present for JwtRegisteredClaimNames

namespace AgriMartAPI.Controllers
{
    [Authorize] // Requires authentication for all cart actions
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartRepository _cartRepo;
        private readonly ILogger<CartController> _logger;

        public CartController(ICartRepository cartRepo, ILogger<CartController> logger)
        {
            _cartRepo = cartRepo;
            _logger = logger;
        }

        // Inner class for AddItem
        public class CartItemUpdateDto
        {
            public Guid ProductId { get; set; }
            public int Quantity { get; set; }
        }

        // Inner class for Update Quantity
        public class UpdateQuantityRequest
        {
            public int Quantity { get; set; }
        }

        // --- MODIFIED: GetCurrentUserId with explicit Guid.Empty handling ---
        private Guid GetCurrentUserId()
        {
            // Prefer JwtRegisteredClaimNames.Sub (standard GUID claim)
            var userIdClaim = User.FindFirstValue(JwtRegisteredClaimNames.Sub);

            // Fallback to ClaimTypes.NameIdentifier if Sub is not found
            if (string.IsNullOrEmpty(userIdClaim))
            {
                userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
            }

            if (Guid.TryParse(userIdClaim, out Guid userId))
            {
                // Crucial: If parsing succeeds but results in an all-zero GUID, it's not a valid user ID.
                if (userId == Guid.Empty)
                {
                    _logger.LogWarning("User ID claim parsed to Guid.Empty. Token likely malformed or user ID not truly set.");
                    // Throwing or returning an invalid GUID will be handled by the caller.
                    throw new InvalidOperationException("User ID claim in the token is invalid (empty GUID).");
                }
                return userId;
            }

            _logger.LogWarning("User ID claim could not be found or parsed to a valid GUID: '{UserIdClaim}'", userIdClaim);
            throw new InvalidOperationException("User ID claim in the token is missing or not a valid GUID.");
        }


        [HttpGet] // GET /api/Cart
        public async Task<IActionResult> GetMyCart()
        {
            try
            {
                var userId = GetCurrentUserId(); // This will throw if ID is invalid/empty

                // --- NEW CHECK: Ensure userId is not empty after extraction ---
                if (userId == Guid.Empty)
                {
                    return Unauthorized("User ID claim is missing or invalid in the token.");
                }

                var cartItems = await _cartRepo.GetCartItems(userId);
                return Ok(cartItems);
            }
            catch (InvalidOperationException ex) // Catch specific user ID issues
            {
                _logger.LogWarning(ex, "Unauthorized attempt to get cart: {Message}", ex.Message);
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while getting the user's cart.");
                return StatusCode(500, "An internal server error occurred.");
            }
        }

        [HttpPost] // POST /api/Cart
        public async Task<IActionResult> AddItem([FromBody] CartItemUpdateDto item)
        {
            try
            {
                var userId = GetCurrentUserId(); // This will throw if ID is invalid/empty

                // --- NEW CHECK: Ensure userId is not empty after extraction ---
                if (userId == Guid.Empty)
                {
                    return Unauthorized("User ID claim is missing or invalid in the token.");
                }

                var result = await _cartRepo.AddOrUpdateItem(userId, item.ProductId, item.Quantity);

                if (!result)
                {
                    return StatusCode(500, "An error occurred while adding the item to the cart.");
                }

                return Ok(new { message = "Item added to cart successfully." });
            }
            catch (InvalidOperationException ex) // Catch specific user ID issues
            {
                _logger.LogWarning(ex, "Unauthorized attempt to add item to cart: {Message}", ex.Message);
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding an item to the cart.");
                return StatusCode(500, "An internal server error occurred.");
            }
        }

        [HttpPut("item/{productId}")] // PUT /api/Cart/item/{productId}
        public async Task<IActionResult> UpdateItemQuantity(Guid productId, [FromBody] UpdateQuantityRequest request)
        {
            try
            {
                if (request.Quantity <= 0)
                {
                    return await RemoveItem(productId); // Calls the delete method directly
                }

                var userId = GetCurrentUserId(); // This will throw if ID is invalid/empty

                // --- NEW CHECK: Ensure userId is not empty after extraction ---
                if (userId == Guid.Empty)
                {
                    return Unauthorized("User ID claim is missing or invalid in the token.");
                }

                var result = await _cartRepo.UpdateItemQuantity(userId, productId, request.Quantity);

                if (!result)
                {
                    return NotFound("Item not found in cart or update failed.");
                }
                return NoContent();
            }
            catch (InvalidOperationException ex) // Catch specific user ID issues
            {
                _logger.LogWarning(ex, "Unauthorized attempt to update item quantity: {Message}", ex.Message);
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while updating item quantity.");
                return StatusCode(500, "An internal server error occurred.");
            }
        }

        [HttpDelete("{productId}")] // DELETE /api/Cart/{productId}
        public async Task<IActionResult> RemoveItem(Guid productId)
        {
            try
            {
                var userId = GetCurrentUserId(); // This will throw if ID is invalid/empty

                // --- NEW CHECK: Ensure userId is not empty after extraction ---
                if (userId == Guid.Empty)
                {
                    return Unauthorized("User ID claim is missing or invalid in the token.");
                }

                var result = await _cartRepo.RemoveItem(userId, productId);

                if (!result)
                {
                    return NotFound("Item not found in cart.");
                }

                return Ok(new { message = "Item removed from cart successfully." });
            }
            catch (InvalidOperationException ex) // Catch specific user ID issues
            {
                _logger.LogWarning(ex, "Unauthorized attempt to remove item from cart: {Message}", ex.Message);
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while removing an item from the cart.");
                return StatusCode(500, "An internal server error occurred.");
            }
        }

        [HttpDelete("clear")] // DELETE /api/Cart/clear
        public async Task<IActionResult> ClearMyCart()
        {
            try
            {
                var userId = GetCurrentUserId(); // This will throw if ID is invalid/empty

                // --- NEW CHECK: Ensure userId is not empty after extraction ---
                if (userId == Guid.Empty)
                {
                    return Unauthorized("User ID claim is missing or invalid in the token.");
                }

                var result = await _cartRepo.ClearCart(userId);

                // This action might not affect any rows if the cart is already empty,
                // so we can consider it successful even if result is false.
                return Ok(new { message = "Cart cleared successfully." });
            }
            catch (InvalidOperationException ex) // Catch specific user ID issues
            {
                _logger.LogWarning(ex, "Unauthorized attempt to clear cart: {Message}", ex.Message);
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while clearing the cart.");
                return StatusCode(500, "An internal server error occurred.");
            }
        }
    }
}