// --- File: AgriMartAPI/Controllers/UserProfilesController.cs ---

using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using System;

namespace AgriMartAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // All endpoints here require authentication
    public class UserProfilesController : ControllerBase
    {
        private readonly IUserProfileRepository _userProfileRepository;

        public UserProfilesController(IUserProfileRepository userProfileRepository)
        {
            _userProfileRepository = userProfileRepository;
        }

        // --- FIX: Changed parameter from 'int' to 'Guid' ---
        [HttpGet("{userId:guid}")]
        public async Task<IActionResult> GetUserProfile(Guid userId)
        {
            // Optional: Check if user is getting their own profile or is a manager
            var currentUserIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (currentUserIdClaim == null || (!Guid.TryParse(currentUserIdClaim, out Guid authenticatedUserId) || authenticatedUserId != userId) && !User.IsInRole("Manager"))
            {
                return Forbid("You are not authorized to view this user profile.");
            }

            var userProfile = await _userProfileRepository.GetUserProfileById(userId);
            if (userProfile == null)
            {
                return NotFound();
            }
            return Ok(userProfile);
        }
        
        // NOTE: CreateUserProfile endpoint is removed from here. Registration should happen via an AuthController that uses AuthService.
        // This controller is for managing existing profiles.

        // --- FIX: Changed parameter from 'int' to 'Guid' ---
        [HttpPut("{userId:guid}")]
        public async Task<IActionResult> UpdateUserProfile(Guid userId, [FromBody] UserProfile userProfile)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // --- FIX: Correctly parse Guid from claims ---
            var currentUserIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!Guid.TryParse(currentUserIdClaim, out Guid authenticatedUserId) || authenticatedUserId != userId)
            {
                return Forbid("You are not authorized to update this user profile.");
            }

            // --- FIX: Correctly compare Guid to Guid ---
            if (userId != userProfile.UserId)
            {
                return BadRequest("User ID in URL does not match ID in body.");
            }

            var existingUser = await _userProfileRepository.GetUserProfileById(userId);
            if (existingUser == null)
            {
                return NotFound("User profile not found.");
            }

            existingUser.Name = userProfile.Name;
            existingUser.PhoneNumber = userProfile.PhoneNumber;

            var updated = await _userProfileRepository.UpdateUserProfile(existingUser);
            if (updated)
            {
                return NoContent();
            }
            return StatusCode(500, "User profile update failed.");
        }
    }
}