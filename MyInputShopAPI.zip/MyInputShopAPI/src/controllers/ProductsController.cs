// --- File: AgriMartAPI/Controllers/ProductsController.cs ---

using AgriMartAPI.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using AgriMartAPI.Models;
using System; // REQUIRED for Guid

namespace AgriMartAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductRepository _productRepository;

        public ProductsController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        [HttpGet] // GET /api/products
        public async Task<IActionResult> GetProducts()
        {
            var products = await _productRepository.GetAllProducts();
            return Ok(products);
        }

        [HttpGet("{id}")] // GET /api/products/{id}
        public async Task<IActionResult> GetProductById(Guid id) // <-- CHANGED from 'int' to 'Guid'
        {
            var product = await _productRepository.GetProductById(id);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }

        [HttpGet("search")] // GET /api/products/search?q={searchTerm}
        public async Task<IActionResult> SearchProducts([FromQuery] string q)
        {
            if (string.IsNullOrWhiteSpace(q))
            {
                var products = await _productRepository.GetAllProducts();
                return Ok(products);
            }

            var searchResults = await _productRepository.SearchProductsAsync(q);
            return Ok(searchResults);
        }
    }
}