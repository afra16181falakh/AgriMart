// using AgriMartAPI.Repositories;
// using Microsoft.AspNetCore.Mvc;
// using Microsoft.Extensions.Logging;
// using System;
// using System.Threading.Tasks;

// namespace AgriMartAPI.Controllers
// {
//     [Route("api/[controller]")]
//     [ApiController]
//     public class WishlistController : ControllerBase
//     {
//         private readonly IWishlistRepository _wishlistRepo;
//         private readonly ILogger<WishlistController> _logger;

//         public WishlistController(IWishlistRepository wishlistRepo, ILogger<WishlistController> logger)
//         {
//             _wishlistRepo = wishlistRepo;
//             _logger = logger;
//         }

//         [HttpGet("{userId}")]
//         public async Task<IActionResult> GetWishlist(string userId)
//         {
//             try
//             {
//                 var items = await _wishlistRepo.GetByUserId(userId); // CORRECTED
//                 return Ok(items);
//             }
//             catch (Exception ex)
//             {
//                 _logger.LogError(ex, "Error getting wishlist for user {UserId}", userId);
//                 return StatusCode(500, "An internal server error occurred.");
//             }
//         }

//         [HttpPost("{userId}/{productId}")]
//         public async Task<IActionResult> AddToWishlist(string userId, string productId)
//         {
//             try
//             {
//                 await _wishlistRepo.AddItem(userId, productId); // CORRECTED
//                 return Ok();
//             }
//             catch (Exception ex)
//             {
//                 _logger.LogError(ex, "Error adding item {ProductId} to wishlist for user {UserId}", productId, userId);
//                 return StatusCode(500, "An internal server error occurred.");
//             }
//         }

//         [HttpDelete("{userId}/{productId}")]
//         public async Task<IActionResult> RemoveFromWishlist(string userId, string productId)
//         {
//             try
//             {
//                 var success = await _wishlistRepo.RemoveItem(userId, productId); // CORRECTED
//                 if (!success) return NotFound();
//                 return NoContent();
//             }
//             catch (Exception ex)
//             {
//                 _logger.LogError(ex, "Error removing item {ProductId} from wishlist for user {UserId}", productId, userId);
//                 return StatusCode(500, "An internal server error occurred.");
//             }
//         }
//     }
// }