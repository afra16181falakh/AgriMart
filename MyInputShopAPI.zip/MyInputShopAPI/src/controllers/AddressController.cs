using AgriMartAPI.Models;
using AgriMartAPI.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Security.Claims;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace AgriMartAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class AddressController : ControllerBase
    {
        private readonly IAddressRepository _addressRepository;
        private readonly ILogger<AddressController> _logger;
        private readonly IErrorHandlingRepository _errorHandlingRepo; // ADD THIS

        public AddressController(IAddressRepository addressRepository, 
                                 ILogger<AddressController> logger,
                                 IErrorHandlingRepository errorHandlingRepo) // ADD THIS
        {
            _addressRepository = addressRepository;
            _logger = logger;
            _errorHandlingRepo = errorHandlingRepo; // INITIALIZE THIS
        }

        [HttpPost]
        public async Task<IActionResult> AddAddress([FromBody] Address address)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var userIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userIdString) || !Guid.TryParse(userIdString, out var userId))
                {
                    _logger.LogWarning("Unauthorized attempt to add address: User ID claim missing or invalid.");
                    return Unauthorized("User ID claim not found or is invalid.");
                }
                
                address.UserId = userId;

                var createdAddress = await _addressRepository.CreateAddress(address);

                return CreatedAtAction(nameof(GetAddressById), new { id = createdAddress.AddressId }, createdAddress);
            }
            catch (Exception ex)
            {
                // LOG TO FILE SYSTEM (using ILogger)
                _logger.LogError(ex, "Error adding new address for user {UserId}", User.FindFirstValue(ClaimTypes.NameIdentifier));

                // LOG TO DATABASE (using new repository)
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                {
                    Message = "Failed to add new address.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = ex.TargetSite?.DeclaringType?.FullName + "." + ex.TargetSite?.Name, // Captures class.method
                    CreatedDate = DateTime.UtcNow
                });

                return StatusCode(500, "An internal server error occurred while adding the address.");
            }
        }

        // ... Other methods (GetMyAddresses, GetAddressById, UpdateAddress, DeleteAddress)
        // Apply similar error logging in their catch blocks as shown above.

        [HttpGet]
        public async Task<IActionResult> GetMyAddresses([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {
            try
            {
                var userIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userIdString) || !Guid.TryParse(userIdString, out var userId))
                {
                    _logger.LogWarning("Unauthorized attempt to get addresses: User ID claim missing or invalid.");
                    return Unauthorized("User ID claim not found or is invalid.");
                }

                var addresses = await _addressRepository.GetAddressByUserId(userId, pageNumber, pageSize);

                if (addresses == null || addresses.Count == 0)
                {
                    _logger.LogInformation("No addresses found for user {UserId}.", userId);
                    return NotFound("No addresses found for this user.");
                }

                return Ok(addresses);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving addresses for user {UserId}", User.FindFirstValue(ClaimTypes.NameIdentifier));
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                {
                    Message = "Failed to retrieve user addresses.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = ex.TargetSite?.DeclaringType?.FullName + "." + ex.TargetSite?.Name,
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred while retrieving addresses.");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetAddressById(int id)
        {
            try
            {
                var userIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userIdString) || !Guid.TryParse(userIdString, out var userId))
                {
                    _logger.LogWarning("Unauthorized attempt to get address by ID {AddressId}: User ID claim missing or invalid.", id);
                    return Unauthorized("User ID claim not found or is invalid.");
                }

                var address = await _addressRepository.GetAddressById(id);

                if (address == null)
                {
                    _logger.LogInformation("Address with ID {AddressId} not found.", id);
                    return NotFound($"Address with ID {id} not found.");
                }

                if (address.UserId != userId)
                {
                    _logger.LogWarning("User {UserId} attempted to access address {AddressId} belonging to another user {OwnerUserId}. Forbidden.", userId, id, address.UserId);
                    return NotFound($"Address with ID {id} not found for this user.");
                }

                return Ok(address);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving address by ID {AddressId}", id);
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                {
                    Message = $"Failed to retrieve address by ID: {id}.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = ex.TargetSite?.DeclaringType?.FullName + "." + ex.TargetSite?.Name,
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred while retrieving the address.");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAddress(int id, [FromBody] Address address)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != address.AddressId)
            {
                return BadRequest("Address ID in URL does not match ID in request body.");
            }

            try
            {
                var userIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userIdString) || !Guid.TryParse(userIdString, out var userId))
                {
                    _logger.LogWarning("Unauthorized attempt to update address {AddressId}: User ID claim missing or invalid.", id);
                    return Unauthorized("User ID claim not found or is invalid.");
                }

                var existingAddress = await _addressRepository.GetAddressById(id);
                if (existingAddress == null)
                {
                    _logger.LogInformation("Attempt to update non-existent address {AddressId}.", id);
                    return NotFound($"Address with ID {id} not found.");
                }

                if (existingAddress.UserId != userId)
                {
                    _logger.LogWarning("User {UserId} attempted to update address {AddressId} belonging to another user {OwnerUserId}. Forbidden.", userId, id, existingAddress.UserId);
                    return Forbid();
                }

                address.UserId = existingAddress.UserId;

                bool success = await _addressRepository.UpdateAddress(address);

                if (!success)
                {
                    _logger.LogError("Failed to update address {AddressId} for user {UserId}. Repository returned false.", id, userId);
                    await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                    {
                        Message = $"Failed to update address: {id}. Repository indicated no rows affected.",
                        SystemMessage = "Update operation returned false, possibly due to concurrent modification or ID not found during update.",
                        Type = "UpdateFailure",
                        Line = "AddressController.UpdateAddress", // More generic for non-exception failure
                        CreatedDate = DateTime.UtcNow
                    });
                    return StatusCode(500, "Failed to update address. It might have been deleted or not found during the update process.");
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating address {AddressId} for user {UserId}", id, User.FindFirstValue(ClaimTypes.NameIdentifier));
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                {
                    Message = $"Failed to update address by ID: {id}.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = ex.TargetSite?.DeclaringType?.FullName + "." + ex.TargetSite?.Name,
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred while updating the address.");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAddress(int id)
        {
            try
            {
                var userIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userIdString) || !Guid.TryParse(userIdString, out var userId))
                {
                    _logger.LogWarning("Unauthorized attempt to delete address {AddressId}: User ID claim missing or invalid.", id);
                    return Unauthorized("User ID claim not found or is invalid.");
                }

                var existingAddress = await _addressRepository.GetAddressById(id);
                if (existingAddress == null)
                {
                    _logger.LogInformation("Attempt to delete non-existent address {AddressId}.", id);
                    return NotFound($"Address with ID {id} not found.");
                }

                if (existingAddress.UserId != userId)
                {
                    _logger.LogWarning("User {UserId} attempted to delete address {AddressId} belonging to another user {OwnerUserId}. Forbidden.", userId, id, existingAddress.UserId);
                    return Forbid();
                }

                bool success = await _addressRepository.DeleteAddress(id);

                if (!success)
                {
                    _logger.LogError("Failed to delete address {AddressId} for user {UserId}. Repository returned false.", id, userId);
                    await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                    {
                        Message = $"Failed to delete address: {id}. Repository indicated no rows affected.",
                        SystemMessage = "Delete operation returned false, possibly due to concurrent deletion or ID not found during delete.",
                        Type = "DeleteFailure",
                        Line = "AddressController.DeleteAddress", // More generic for non-exception failure
                        CreatedDate = DateTime.UtcNow
                    });
                    return StatusCode(500, "Failed to delete address. It might have been deleted by another process.");
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting address {AddressId} for user {UserId}", id, User.FindFirstValue(ClaimTypes.NameIdentifier));
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                {
                    Message = $"Failed to delete address by ID: {id}.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = ex.TargetSite?.DeclaringType?.FullName + "." + ex.TargetSite?.Name,
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred while deleting the address.");
            }
        }
    }
}