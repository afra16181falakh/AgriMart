// src/AgriMartAPI/Controllers/ErrorController.cs
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using AgriMartAPI.Repositories; // For IErrorHandlingRepository
using AgriMartAPI.Models; // For ErrorHandling
using System;
using System.Threading.Tasks;

namespace AgriMartAPI.Controllers
{
    [ApiExplorerSettings(IgnoreApi = true)] // Exclude from Swagger docs
    [Route("Error")] // Matches app.UseExceptionHandler("/Error")
    public class ErrorController : ControllerBase
    {
        private readonly ILogger<ErrorController> _logger;
        private readonly IErrorHandlingRepository _errorHandlingRepo;

        public ErrorController(ILogger<ErrorController> logger, IErrorHandlingRepository errorHandlingRepo)
        {
            _logger = logger;
            _errorHandlingRepo = errorHandlingRepo;
        }

        [Route("")] // Handles requests to /Error
        public async Task<IActionResult> Error()
        {
            var context = HttpContext.Features.Get<IExceptionHandlerFeature>();
            var exception = context?.Error; // The actual exception that occurred

            if (exception != null)
            {
                _logger.LogError(exception, "An unhandled exception occurred during request: {Message}", exception.Message);

                // Log to database
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                {
                    Message = "An unhandled application error occurred.",
                    SystemMessage = exception.Message + " | StackTrace: " + exception.StackTrace,
                    Type = exception.GetType().Name,
                    Line = "Global Exception Handler", // Or extract more detail from exception.TargetSite if possible
                    CreatedDate = DateTime.UtcNow
                });
            }
            else
            {
                _logger.LogWarning("Unhandled error occurred, but no exception feature found.");
            }

            // Return a generic, non-sensitive error response for production
            return Problem(
                detail: "An unexpected error occurred. Please try again later.",
                title: "Internal Server Error",
                statusCode: 500
            );
        }
    }
}