using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization; // Make sure this is there if you use [Authorize]

namespace AgriMartAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    // [Authorize(Roles = "Manager")] // Example: Uncomment and configure if specific roles are required for ALL actions
    public class DeliveryChargeRulesController : ControllerBase
    {
        private readonly IDeliveryChargeRulesRepository _deliveryChargeRulesRepository;

        public DeliveryChargeRulesController(IDeliveryChargeRulesRepository deliveryChargeRulesRepository)
        {
            _deliveryChargeRulesRepository = deliveryChargeRulesRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllDeliveryChargeRules()
        {
            var rules = await _deliveryChargeRulesRepository.GetAllDeliveryChargeRules();
            return Ok(rules);
        }

        [HttpPost]
        // [Authorize(Roles = "Manager")] // Uncomment and configure if only managers can add rules
        public async Task<IActionResult> AddDeliveryChargeRule([FromBody] DeliveryChargeRule rule)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            // If the RuleId comes from the client, you might want to prevent it or set to 0.
            // Assuming DB generates RuleId, so setting it to 0 before passing.
            rule.RuleId = 0; // Ensure ID is not client-provided if DB auto-generates

            var newRuleId = await _deliveryChargeRulesRepository.AddDeliveryChargeRule(rule);
            if (newRuleId > 0)
            {
                rule.RuleId = newRuleId; // Assign the new ID returned from the database
                // Correctly references the current method for CreatedAtAction
                // Note: For GetAll, you usually need a route like 'api/DeliveryChargeRules' or '{id}' to get one
                // For simplicity, here, pointing to the collection endpoint.
                return CreatedAtAction(nameof(GetAllDeliveryChargeRules), new { id = newRuleId }, rule);
            }
            return StatusCode(500, "Failed to add delivery charge rule.");
        }

        [HttpPut("{id}")]
        // [Authorize(Roles = "Manager")] // Uncomment and configure if only managers can update rules
        public async Task<IActionResult> UpdateDeliveryChargeRule(int id, [FromBody] DeliveryChargeRule rule)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            // Ensure the ID in the URL matches the ID in the body for consistency
            if (id != rule.RuleId)
            {
                return BadRequest("Rule ID in URL does not match ID in body.");
            }
            var updated = await _deliveryChargeRulesRepository.UpdateDeliveryChargeRule(rule); // Pass the full model
            if (updated)
            {
                return NoContent(); // 204 No Content for successful update (standard for PUT)
            }
            return NotFound("Delivery charge rule not found or update failed.");
        }

        [HttpDelete("{id}")]
        // [Authorize(Roles = "Manager")] // Uncomment and configure if only managers can delete rules
        public async Task<IActionResult> DeleteDeliveryChargeRule(int id)
        {
            var deleted = await _deliveryChargeRulesRepository.DeleteDeliveryChargeRule(id);
            if (deleted)
            {
                return NoContent(); // 204 No Content for successful deletion
            }
            return NotFound("Delivery charge rule not found or deletion failed.");
        }
    }
}