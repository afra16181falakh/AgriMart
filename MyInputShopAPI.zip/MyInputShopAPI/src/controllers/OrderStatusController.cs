using AgriMartAPI.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace AgriMartAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderStatusController : ControllerBase
    {
        private readonly IOrderStatusRepository _orderStatusRepository;
        private readonly ILogger<OrderStatusController> _logger;

        public OrderStatusController(IOrderStatusRepository orderStatusRepository, ILogger<OrderStatusController> logger)
        {
            _orderStatusRepository = orderStatusRepository;
            _logger = logger;
        }

        // GET: api/orderstatus
        [HttpGet]
        public async Task<IActionResult> GetAllOrderStatuses()
        {
            try
            {
                var statuses = await _orderStatusRepository.GetAllOrderStatusAsync();
                _logger.LogInformation("Successfully retrieved all order statuses.");
                return Ok(statuses);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching order statuses.");
                // Return a generic server error message to the client
                return StatusCode(500, "An unexpected error occurred. Please try again later.");
            }
        }
    }
}