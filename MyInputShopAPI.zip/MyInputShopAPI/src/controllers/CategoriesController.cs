using AgriMartAPI.Models; // CORRECTED: Changed 'models' to 'Models'
using AgriMartAPI.Repositories; // Contains ICategoryRepository
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using System.Collections.Generic; // Added for List<Category>

namespace AgriMartAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly ICategoryRepository _categoryRepo;
        private readonly ILogger<CategoriesController> _logger;
        private readonly IErrorHandlingRepository _errorHandlingRepo; // ADDED: Error handling repository

        public CategoriesController(ICategoryRepository categoryRepo, 
                                    ILogger<CategoriesController> logger,
                                    IErrorHandlingRepository errorHandlingRepo) // ADDED: Constructor injection
        {
            _categoryRepo = categoryRepo;
            _logger = logger;
            _errorHandlingRepo = errorHandlingRepo; // INITIALIZED
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var categories = await _categoryRepo.GetAllCategories();
                return Ok(categories);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while getting all categories.");
                // ADDED: Log error to database
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                {
                    Message = "Failed to retrieve all categories.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = $"{ControllerContext.ActionDescriptor.ControllerName}.{ControllerContext.ActionDescriptor.ActionName}",
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred.");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var category = await _categoryRepo.GetCategoryById(id);
                if (category == null)
                {
                    _logger.LogInformation("Category with ID {Id} not found.", id);
                    return NotFound();
                }
                return Ok(category);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while getting category {Id}.", id);
                // ADDED: Log error to database
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                {
                    Message = $"Failed to retrieve category by ID: {id}.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = $"{ControllerContext.ActionDescriptor.ControllerName}.{ControllerContext.ActionDescriptor.ActionName}",
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred.");
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Category category)
        {
            try
            {
                if (category == null)
                {
                    _logger.LogWarning("Create category request body is null.");
                    return BadRequest("Category data is null.");
                }

                var createdCategory = await _categoryRepo.CreateCategory(category);

                return CreatedAtAction(nameof(GetById), new { id = createdCategory.Id }, createdCategory);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while creating a new category.");
                // ADDED: Log error to database
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                {
                    Message = $"Failed to create new category: {category?.Name ?? "Unknown"}.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = $"{ControllerContext.ActionDescriptor.ControllerName}.{ControllerContext.ActionDescriptor.ActionName}",
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred.");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Category category)
        {
            if (id != category.Id)
            {
                _logger.LogWarning("ID mismatch in UpdateCategory: URL ID={UrlId}, Body ID={BodyId}", id, category.Id);
                return BadRequest("ID mismatch between URL and request body.");
            }

            try
            {
                var wasSuccessful = await _categoryRepo.UpdateCategory(category);

                if (!wasSuccessful)
                {
                    _logger.LogInformation("Category with ID {Id} not found for update.", id);
                    // No database log here, as NotFound is a business logic outcome.
                    return NotFound($"Category with ID {id} not found.");
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while updating category {Id}.", id);
                // ADDED: Log error to database
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                {
                    Message = $"Failed to update category with ID: {id}.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = $"{ControllerContext.ActionDescriptor.ControllerName}.{ControllerContext.ActionDescriptor.ActionName}",
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred.");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var result = await _categoryRepo.DeleteCategory(id);
                if (!result)
                {
                    _logger.LogInformation("Category with ID {Id} not found for deletion.", id);
                    // No database log here, as NotFound is a business logic outcome.
                    return NotFound();
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while deleting category {Id}.", id);
                // ADDED: Log error to database
                await _errorHandlingRepo.CreateErrorLog(new ErrorHandling
                {
                    Message = $"Failed to delete category with ID: {id}.",
                    SystemMessage = ex.Message + " | StackTrace: " + ex.StackTrace,
                    Type = ex.GetType().Name,
                    Line = $"{ControllerContext.ActionDescriptor.ControllerName}.{ControllerContext.ActionDescriptor.ActionName}",
                    CreatedDate = DateTime.UtcNow
                });
                return StatusCode(500, "An internal server error occurred.");
            }
        }
    }
}