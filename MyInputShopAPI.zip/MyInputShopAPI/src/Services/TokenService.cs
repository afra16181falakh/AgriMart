using AgriMartAPI.Models; // Assuming UserProfile is here
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AgriMartAPI.Interfaces; // <<< ADDED THIS LINE

namespace AgriMartAPI.Services
{
    // This class needs to implement ITokenService, so ITokenService must be in scope
    public class TokenService : ITokenService // ITokenService should be defined in AgriMartAPI.Interfaces
    {
        private readonly IConfiguration _configuration;

        public TokenService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // Implementation of ITokenService.GenerateJwtToken
        public async Task<string> GenerateJwtToken(UserProfile user)
        {
            // CS1998 warning fixed by wrapping synchronous work in Task.Run
            return await Task.Run(() =>
            {
                var claims = new[]
                {
                    new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                    new Claim(ClaimTypes.Email, user.Email),
                    new Claim(ClaimTypes.Name, user.Name),
                    new Claim(ClaimTypes.MobilePhone, user.PhoneNumber ?? string.Empty),
                    new Claim(ClaimTypes.Role, user.Role ?? "Customer")
                };

                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"] ?? throw new InvalidOperationException("JWT Key not configured.")));
                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                var token = new JwtSecurityToken(
                    issuer: _configuration["Jwt:Issuer"],
                    audience: _configuration["Jwt:Audience"],
                    claims: claims,
                    expires: DateTime.Now.AddHours(2),
                    signingCredentials: creds
                );

                return new JwtSecurityTokenHandler().WriteToken(token);
            });
        }
    }
}