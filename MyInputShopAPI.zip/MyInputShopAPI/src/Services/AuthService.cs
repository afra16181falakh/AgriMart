// --- File: AgriMartAPI/Services/AuthService.cs ---

using AgriMartAPI.Interfaces;
using AgriMartAPI.Models;
using System;
using System.Threading.Tasks;
using BCrypt.Net; // For password hashing

namespace AgriMartAPI.Services
{
    public class AuthService : IAuthService
    {
        private readonly IUserProfileRepository _userProfileRepo;
        private readonly ITokenService _tokenService;

        // --- FIX: Removed IConfiguration dependency, as it should be in TokenService ---
        public AuthService(IUserProfileRepository userProfileRepo, ITokenService tokenService)
        {
            _userProfileRepo = userProfileRepo;
            _tokenService = tokenService;
        }

        public async Task<UserProfile?> RegisterUserAsync(string name, string email, string phoneNumber, string password)
        {
            string passwordHash = BCrypt.Net.BCrypt.HashPassword(password);

            var newUserProfile = new UserProfile
            {
                Name = name,
                Email = email,
                PhoneNumber = phoneNumber,
                PasswordHash = passwordHash,
                CreatedDate = DateTime.UtcNow,
                IsActive = true,
                Role = "Customer"
            };

            // --- FIX: Method now returns Guid? ---
            Guid? newUserId = await _userProfileRepo.CreateUserProfile(newUserProfile);

            // --- FIX: Correctly check Guid? for value ---
            if (newUserId.HasValue && newUserId.Value != Guid.Empty)
            {
                newUserProfile.UserId = newUserId.Value;
                return newUserProfile;
            }
            return null;
        }

        public async Task<bool> GenerateOtpAsync(string phoneNumber)
        {
            Console.WriteLine($"OTP generated for {phoneNumber}: 123456 (simulated)");
            return await Task.FromResult(true);
        }

        public async Task<string?> VerifyOtpAndGenerateTokenAsync(string phoneNumber, string otp)
        {
            if (otp != "123456")
            {
                return null;
            }

            // --- FIX: Calls the correct, existing method ---
            var user = await _userProfileRepo.GetUserProfileByPhoneNumber(phoneNumber);
            if (user == null)
            {
                return null;
            }
            
            return await _tokenService.GenerateJwtToken(user);
        }

        // --- FIX: This correctly delegates to the token service ---
        public async Task<string> GenerateJwtToken(UserProfile user)
        {
            return await _tokenService.GenerateJwtToken(user);
        }
    }
}