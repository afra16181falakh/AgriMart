using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace AgriMartAPI.Middleware // IMPORTANT: Adjust this namespace if your root project namespace is different
{
    public class RequestTimerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<RequestTimerMiddleware> _logger;

        public RequestTimerMiddleware(RequestDelegate next, ILogger<RequestTimerMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var stopwatch = Stopwatch.StartNew();

            await _next(context); // Call the next middleware in the pipeline

            stopwatch.Stop();
            _logger.LogInformation(
                "Request {Method} {Path} took {ElapsedMilliseconds} ms",
                context.Request.Method,
                context.Request.Path,
                stopwatch.ElapsedMilliseconds);
        }
    }

    // Extension method for cleaner registration
    public static class RequestTimerMiddlewareExtensions
    {
        public static IApplicationBuilder UseRequestTimer(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RequestTimerMiddleware>();
        }
    }
}